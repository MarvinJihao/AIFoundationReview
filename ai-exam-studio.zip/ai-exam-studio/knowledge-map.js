/* A reasoned learning map. Connections are explanatory, not an official syllabus order. */
(()=>{'use strict';
const motivations={
regression:'Before building a network, we need a precise learning problem: what is predicted, which parameters change, and what makes a prediction good? Regression introduces features and an objective; probability links and cross-entropy extend this language to classification.',
optimisation:'Writing a loss does not tell us how to find its parameters. Differentiation produces a direction for improvement, while gradient descent turns it into updates. Neural-network examples then reveal why local progress does not guarantee a globally best fit.',
networks:'A linear model can only combine the features it is given. If fixed features cannot distinguish inputs or express the required boundary, learning the features themselves becomes useful. Affine layers and nonlinearities create this trainable composition.',
backprop:'A network may have thousands of shared intermediate calculations and millions of parameters. Differentiating every parameter from scratch repeats work. Backpropagation reuses the chain rule, carrying loss sensitivities backward through the saved forward computation.',
pca:'High-dimensional measurements can be redundant or vary mainly along a few directions. Before using nonlinear networks, PCA supplies a transparent linear representation: rotate into variance directions, retain a small subspace and quantify what reconstruction loses.',
ica:'PCA removes linear correlation, but uncorrelated coordinates can still be dependent. If observations are mixtures of independent processes, variance alone does not recover the sources. ICA adds independence and non-Gaussian structure to the representation objective.',
autoencoders:'A single linear PCA subspace may not describe a curved data manifold. An autoencoder learns a more flexible reconstruction code. Ordinary codes need not support prior sampling, motivating VAE regularisation; a wide dictionary needs selective use, motivating sparse autoencoders.',
convolution:'A fully connected image layer ignores locality and learns separate weights at every position. Images contain repeated local patterns. Shared spatial kernels exploit this structure while reducing parameters and building hierarchical receptive fields.',
vision:'Convolution gives a useful operation, not a complete solution to every image task. Deep backbones, patch attention, region proposals and dense decoders organise representations around classification, detection, segmentation, scale and computation constraints.',
generative:'Recognition predicts a label or description of observed data. Generation asks how to produce new data, requiring a distribution and a sampling mechanism. The slides compare adversarial, latent-variable, autoregressive, invertible and denoising routes to that goal.',
language:'Text is discrete and a one-hot word ID has no learned semantic geometry. Tokenisation makes usable units; embedding methods learn from context. Static word vectors still cannot resolve every context-dependent meaning, preparing the need for contextual sequence models.',
attention:'A fixed word representation cannot decide which earlier words matter for the current prediction. Attention makes retrieval depend on the input itself. Queries and keys select context, values carry information, and causal masks align training with generation.'
};
const relations=[
['regression','optimisation','enables','A chosen empirical loss becomes the differentiable objective used by parameter updates.'],
['regression','networks','generalises','A network replaces a fixed feature map with learned nonlinear feature composition.'],
['regression','backprop','initialises','The task-specific loss determines the first backward row: squared error or cross-entropy.'],
['optimisation','networks','trains','Gradient updates fit weights; network nonlinearity makes the optimisation landscape nonconvex.'],
['networks','backprop','requires','The forward composition defines which local derivatives must be chained and reused.'],
['backprop','optimisation','supplies','Backprop computes a gradient; gradient descent, momentum or Adam decides the update.'],
['pca','ica','contrasts','PCA decorrelates with second-order information; ICA seeks stronger independence using non-Gaussian structure.'],
['pca','autoencoders','motivates','A linear reconstruction subspace suggests learning a nonlinear encoder and decoder.'],
['ica','autoencoders','compares','Independent coordinates and sparse dictionary features are different objectives for disentangling representations.'],
['networks','autoencoders','implements','Encoder and decoder are neural feature maps trained by reconstruction-based losses.'],
['backprop','autoencoders','trains','Reconstruction gradients train encoders; VAE reparameterisation restores a pathwise gradient through sampled latents.'],
['networks','convolution','specialises','Local connectivity and spatial weight sharing constrain an otherwise general learned affine operation.'],
['convolution','vision','builds','CNN operators compose into backbones and task heads with predictable shapes and costs.'],
['attention','vision','transfers','Image patches can be embedded as tokens and processed by global or windowed attention.'],
['autoencoders','generative','connects','VAEs generate by prior sampling; latent diffusion uses a learned compressed representation.'],
['generative','attention','shares','Autoregressive image and language models both prevent future-information leakage.'],
['language','attention','provides','Token embeddings become the sequence representations projected into queries, keys and values.'],
['regression','attention','normalises','Row-wise softmax turns query–key scores into a probability-weighted mixture of values.'],
['backprop','attention','trains','Attention is a differentiable composition whose parameters can be learned from token losses.'],
['ica','language','interprets','ICA on static embeddings probes semantic directions; their interpretation must be checked empirically.'],
['vision','generative','extends','Understanding image representations provides reusable encoders, decoders and features for synthesis.'],
['optimisation','vision','constrains','Architectures trade off parameter count, optimisation difficulty, generalisation and actual runtime.']
].map(([from,to,kind,why])=>({from,to,kind,why}));
const sections={};
function put(topic,id,rows){sections[topic+':'+id]=rows.map((r,i)=>({id:'p'+(i+1),label:r[0],knowledge:r[1],exam:r[2],refs:r[3].split(',')}));}
put('regression','least-squares',[
['Constant least-squares predictor','The derivative of Σ(c−yᵢ)² is 2Σ(c−yᵢ), so the minimiser is the target mean.','Identify the mean, calculate it, and evaluate residual squares if requested.','S:a1,G:G01'],
['Fixed feature maps','A model can be nonlinear in x while remaining linear in its unknown coefficients.','Write an explicit feature row, including an intercept feature.','S:a3,G:G02'],
['Design-matrix shapes','One row corresponds to each observation; each column is one feature.','State X, θ and y shapes before matrix multiplication.','G:G05,T:nn1'],
['Normal equations and rank','The inverse formula requires XᵀX to be invertible; full column rank is the relevant condition.','Build XᵀX and Xᵀy, check the determinant and verify fitted residuals.','G:G05']]);
put('regression','probability',[
['Logit to binary probability','Sigmoid maps an unrestricted score into (0,1).','Explain why a real-valued logit is not itself a probability.','S:a6,G:G04'],
['Softmax normalisation','Exponentiate class logits and divide by their sum, separately for each example.','Compute class probabilities and check that they sum to one.','S:a4,S:a5,G:G03'],
['Choose the observed-label loss','Binary CE uses y and 1−y; multiclass CE is the negative log probability of the correct class.','Use natural logs and select p versus 1−p correctly.','S:a7,G:G03'],
['Stable softmax and shift invariance','Adding a common constant to logits does not change their probabilities.','Justify subtracting the maximum logit before exponentiation.','G:G06,Q:q5']]);
put('regression','sample-probability',[
['Equal logits share probability','Identical class logits produce identical softmax probabilities.','Calculate the supplied (1,1,0) vector before rounding.','S:a5,Q:q3'],
['Confidence changes the loss','A confident correct prediction has small CE; the same confidence on a wrong label has large CE.','Compute both target cases for p=0.9 and explain the asymmetry.','S:a7,Q:q4'],
['Sigmoid sketch landmarks','The sigmoid is increasing, passes through (0,1/2), and approaches 0 and 1.','Label midpoint and both asymptotes on a sketch.','S:a9,Q:q6'],
['Accuracy is not cross-entropy','Correct class labels can coexist with positive loss because correct-label probabilities are below one.','Distinguish decision threshold, confidence and probabilistic loss.','T:nn8,G:G18']]);
put('optimisation','updates',[
['Direction and learning rate','Gradient descent subtracts η∇L. Its magnitude controls progress and stability.','Explain small-step slowness and large-step overshoot.','S:a2,G:G08'],
['Epoch versus update','An epoch is one dataset pass; a minibatch normally produces one update.','Count updates, explicitly stating treatment of an incomplete batch.','S:a13,G:G07'],
['Sum versus mean gradients','Differentiation commutes with summation; averaging losses averages their gradients.','Keep the loss reduction consistent throughout a backward pass.','G:G21'],
['Momentum versus Adam','Momentum accumulates gradients; Adam also tracks a second moment to rescale coordinates.','Use the formula-sheet convention and state whether bias correction is omitted.','G:G10,G:G12']]);
put('optimisation','local-minima',[
['Stationary is not globally optimal','A zero derivative may occur at a poor local minimum, saddle or other stationary point.','Use the teacher’s minima at −3 and 3 as a concrete counterexample.','T:nn6,G:G11'],
['Different initialisations, different basins','The same update rule can approach minima with different objective values.','Calculate iterates and their losses from both initial values.','T:nn6,G:G11'],
['Piecewise derivative selection','Different parameter regions have different quadratic formulas.','Select the current region before evaluating a gradient.','T:nn6,Q:q10'],
['Monotone improvement is local evidence','Loss can decrease at every step while converging to a suboptimal loss of 8.','Explain why a descending sequence does not prove global optimality.','G:G11,Q:q9']]);
put('optimisation','heuristics',[
['Initialisation and architecture heuristics','Restarts and additional capacity may help, but supply no universal guarantee.','Assess a claim rather than asserting that width always fixes training.','G:G12'],
['What minibatch noise can and cannot do','A minibatch gradient may avoid full-gradient cancellation, but can also be zero.','Explain why SGD need not escape every nonglobal stationary point.','G:G12'],
['Underfitting diagnostic','High, similar training and validation losses indicate inadequate fit or optimisation.','Describe both curves and a plausible cause.','S:a14,G:G09'],
['Generalisation gap','Low training loss with a much higher validation loss is consistent with overfitting.','Use validation for choices and preserve the test set for evaluation.','G:G09']]);
put('networks','affine',[
['Row-vector weight convention','W has one row per incoming coordinate and one column per output unit.','Check xW+b shapes and explain a matrix entry.','T:nn1,G:G13'],
['Bias placement','Each output coordinate receives its own bias after the weighted sum.','Count one bias per unit, not per input connection.','S:a10,G:G13'],
['Collapsing affine compositions','Two affine layers combine as xAC+(bC+d).','Give the effective weight and bias, including both original biases.','T:nn2,G:G14'],
['Why nonlinearities matter','An intervening nonlinearity can change slopes and increase the function class.','Demonstrate non-affinity using a piecewise restriction, not just one changed value.','S:a11,T:nn2']]);
put('networks','shapes',[
['Layer widths and depth','The supplied convention counts hidden and output layers but excludes the input.','Translate an architecture into ordered widths.','T:nn1,G:G13'],
['Weight and bias shapes','A d→m affine layer has a d×m matrix and a 1×m bias row.','State all matrix and hidden-row dimensions.','T:nn1'],
['Total parameter count','Sum dᵣ₋₁dᵣ+dᵣ across layers.','Separate weights and biases before adding.','S:a10,G:G13'],
['Hierarchical feature efficiency','Nonlinear layers build features of features, enabling useful compositional representations.','Explain what depth adds beyond multiplying more linear matrices.','S:a8,S:a11']]);
put('networks','forward',[
['Compute preactivations first','An affine sum and its nonlinear activation are different saved quantities.','Show a₁ before applying ReLU componentwise.','T:nn3,G:G17'],
['Inactive versus active ReLUs','Negative preactivations become zero; positive ones pass unchanged.','Identify which hidden feature is inactive.','T:nn3,G:G17'],
['A signed output from nonnegative hidden units','The final weights and bias can be negative, and the output is not automatically rectified.','Compute f without adding an unstated output activation.','T:nn3'],
['Task-dependent output interpretation','A scalar can be a regression prediction or a binary logit, leading to different losses.','Calculate regression SSE and sigmoid CE for the same forward output.','T:nn3,G:G17']]);
put('networks','relu-functions',[
['Breakpoints and slopes','An affine ReLU changes its formula where its preactivation is zero.','Solve the breakpoint and sketch both linear pieces.','S:a12,G:G15'],
['Constructing a piecewise-linear tent','Weighted shifted ReLUs add and cancel slopes in chosen intervals.','Give a piecewise function and network parameters that realise it.','T:nn7,G:G18'],
['XOR via learned nonlinear features','Two ReLU difference features can separate the four XOR examples.','List scores and predicted classes, then interpret positive score scaling.','T:nn8'],
['ReLU at zero','Its left derivative is 0 and right derivative is 1. A software multiplier is a convention.','Distinguish an ordinary derivative from a computational choice.','T:nn5,Q:q14']]);
put('backprop','remaining',[
['Remaining-loss function Jᵣ','Jᵣ starts at a hypothetical preactivation while holding target and later parameters fixed.','Define its argument and identify which quantities are held fixed.','T:bp1,G:G24'],
['Backward row δᵣ','The row is the loss sensitivity to the current preactivation.','State its shape before propagating it.','G:G24'],
['Outer-product weight gradient','Incoming feature transpose times δ produces a matrix matching W.','Calculate xᵀδ entrywise and verify dimensions.','G:G19,T:bp1'],
['Bias gradient reuse','A bias enters its preactivation with derivative one.','Reuse δ as the bias gradient instead of recomputing a chain.','G:G19,G:G24']]);
put('backprop','initial',[
['Squared-error initialisation','For the exact loss (f−y)², the output derivative is 2(f−y).','Retain the factor 2; do not silently introduce a half.','S:b1,T:bp1'],
['Binary CE initialisation','After sigmoid and CE, the derivative with respect to the logit simplifies to p−y.','Avoid multiplying by sigmoid derivative again.','T:bp2,G:G04'],
['Multiclass CE initialisation','Subtract the target one-hot vector from the probability row.','Retain negative target-class entries.','T:bp3,G:G22'],
['Batch reduction','Per-example gradients combine by the same sum or mean used in the loss.','Explain how an averaged objective changes the gradient magnitude.','G:G21']]);
put('backprop','scalar',[
['Save the scalar forward chain','The loss depends on a sequence of affine and ReLU operations.','List every intermediate before differentiation.','G:G24'],
['Local derivatives multiply along paths','Each affine operation contributes its weight; ReLU contributes its saved gate.','Work backward using the chain rule in reverse computational order.','G:G24'],
['One sensitivity, multiple parameter gradients','A layer’s backward value is reused for both its bias and incoming weights.','Multiply by the layer input for a weight gradient.','G:G19'],
['Differentiate before updating','All sensitivities must refer to the same forward parameter setting.','Explain why early updates invalidate a manual backward pass.','T:bp1,G:G23']]);
put('backprop','vector-example',[
['Sum downstream contributions','Multiplying δᵣ by Wᵣᵀ adds the contributions of all downstream coordinates.','Show separate output contributions before adding when requested.','T:bp3,G:G24'],
['Gate from preactivation signs','The gate depends on a, not the sign of a gradient coordinate.','Pass a negative gradient through a positive-preactivation unit.','G:G20,T:bp3'],
['Two different causes of zeros','An inactive hidden unit zeros a column; a zero input coordinate zeros a weight-gradient row.','Explain the row and column zeros separately.','T:bp1,S:b1'],
['Simultaneous parameter update','Compute all gradients at the saved parameters and then apply each update.','Give the updated matrix entries and biases with a stated η.','T:bp1,G:G23']]);
put('backprop','derivations',[
['Multivariable chain rule','A coordinate sensitivity sums the contributions of every downstream coordinate.','Derive the row recurrence instead of assuming elementwise multiplication alone.','G:G24'],
['Sigmoid–CE cancellation','The CE probability derivative and σ′ factors cancel to give p−y.','Specify that the result differentiates with respect to the logit.','T:bp2,G:G04'],
['Softmax–CE derivative','Write the loss as −aᵧ+logsumexp(a) and differentiate.','Obtain pₖ−1[k=y] with the correct target coordinate.','G:G06,T:bp3'],
['Computational reuse','Reverse-mode differentiation shares intermediate sensitivities across parameter gradients.','Explain efficiency relative to separately repeating a full chain for each parameter.','G:G24']]);
put('pca','eigen',[
['Invertibility and determinant','A square matrix with zero determinant has no inverse.','Check this before a normal-equation or unmixing inverse.','G:G05,G:G31'],
['Characteristic equation','Eigenvalues satisfy det(A−λI)=0 for a nonzero eigenvector.','Expand the 2×2 determinant and solve for λ.','G:G29'],
['Normalised loading directions','Solve (A−λI)e=0 and normalise the direction.','State unit eigenvectors and recognise sign ambiguity.','G:G25,G:G29'],
['Symmetric spectral decomposition','A real symmetric covariance matrix has an orthonormal eigenbasis.','Write Σ=PDPᵀ and distinguish P from D.','G:G29']]);
put('pca','covariance',[
['Centring removes the mean','PCA score formulas operate on deviations from the mean.','Centre before covariance and restore the mean after reconstruction.','G:G26'],
['Sample covariance convention','The supplied notes use denominator n−1 for sample covariance.','State the convention rather than silently switching to n.','G:G30'],
['Covariance versus correlation','Standardisation changes relative feature scaling and can change PCA directions.','Justify scaling choices in a heterogeneous dataset.','G:G27,G:G30'],
['Decorrelation versus independence','Off-diagonal zero covariance does not rule out nonlinear dependence.','Explain why PCA and ICA solve different representation problems.','G:G32,G:G36']]);
put('pca','scores',[
['Loadings versus scores','Loadings are directions; scores are coordinates of data in those directions.','Use Pᵀ(x−μ) for columns or XcentredP for row observations.','G:G26,G:G29'],
['Retained variance ratio','A component explains λᵢ divided by the sum of eigenvalues.','Sort eigenvalues and calculate the retained fraction.','G:G25,G:G29'],
['Low-rank reconstruction','Reconstruct the retained projection with Pm and add μ.','Compute both the reconstructed point and its residual.','G:G26,G:G29'],
['Projection error interpretation','A pointwise squared error differs from an aggregate explained-variance ratio.','Keep these two quantities separate in a numerical answer.','G:G29']]);
put('pca','pca-cases',[
['Interpretation requires context','PCA discovers mathematical directions; an analyst supplies semantic labels.','Explain the ear-size size/asymmetry example.','G:G30'],
['Constant-sum feature constraint','Eleven vote shares summing to one produce a centred feature dependence.','State a maximum feature rank of ten.','G:G30'],
['Sign and repeated-eigenvalue ambiguity','Flipped eigenvectors or different bases in a tied eigenspace preserve the represented subspace.','Explain differing-looking valid PCA outputs.','G:G28'],
['Variance is not predictive importance','A direction with high unsupervised variance need not best predict labels.','State what PCA optimises and what it does not guarantee.','G:G30']]);
put('ica','unmix',[
['Linear source mixing','Observed coordinates are weighted sums y=Ms of latent source coordinates.','Write the mixing and unmixing equations with compatible shapes.','G:G31,G:G35'],
['Known inverse illustration','If M is known and invertible, W=M⁻¹ recovers the sources in the noiseless model.','Solve a two-equation mixture and identify the assumption.','G:G31'],
['Why PCA is insufficient','Decorrelated coordinates can remain statistically dependent.','Explain the need for information beyond covariance.','G:G32'],
['Recovery ambiguities','Independence does not set source order, scale or sign.','State the ambiguities instead of claiming a unique numerical source identity.','G:G35']]);
put('ica','fastica',[
['Central-limit intuition','Mixtures tend to be more Gaussian than individual non-Gaussian sources under appropriate conditions.','Explain the intuition without asserting it for every arbitrary distribution.','G:G35'],
['Non-Gaussian projection search','FastICA seeks useful non-Gaussian directions after preprocessing.','Describe centre → whiten → optimise rather than treating PCA as the final answer.','G:G35'],
['Gaussian source non-identifiability','A whitened multivariate Gaussian does not select a unique source orientation.','Explain the standard at-most-one-Gaussian-source condition.','G:G33'],
['Assumptions and diagnostics','Noise, noninvertible mixing and dependent sources can undermine a simple ICA model.','Check model adequacy and recovered dependence empirically.','G:G35']]);
put('ica','embeddings-ica',[
['A word vector becomes an observation','Each embedding is a data point whose coordinates can be transformed.','Describe applying ICA to the supplied GloVe representation example.','G:G34'],
['Interpret top activations','Rank words along a component to propose a shared semantic or stylistic property.','Give a plausible interpretation of music-related high-scoring words.','G:G34'],
['Validate rather than cherry-pick','A coherent list is evidence for a hypothesis, not a universal or causal proof.','Check held-out examples and controls.','G:G34,G:G66'],
['Compare representation objectives','PCA, ICA and sparse AEs optimise different notions of useful coordinates.','Compare variance, independence and sparse reconstruction.','G:G36']]);
put('autoencoders','ae',[
['Reconstruction learning','An encoder and decoder learn to reproduce the input through an intermediate representation.','Define an AE and identify the learning target.','S:a15'],
['Bottleneck and useful codes','A bottleneck constrains copying and encourages compression.','Explain denoising, compression and downstream feature uses.','S:a15,G:G60'],
['Linear PCA connection','Linear reconstruction with a suitable bottleneck relates to a principal subspace.','State the relationship without claiming every AE learns exactly the PCA coordinates.','G:G36'],
['Nonlinear generalisation','Flexible encoder/decoder compositions can represent structure beyond one linear subspace.','Explain why nonlinear compression is introduced after linear PCA.','G:G36']]);
put('autoencoders','vae',[
['Distribution instead of a single code','The encoder predicts a latent distribution, commonly via μ and variance.','Contrast an AE code with VAE sampling.','S:a16'],
['ELBO rewards and penalties','Expected reconstruction log-likelihood is rewarded; KL to the prior is subtracted.','State maximise ELBO versus minimise negative ELBO.','S:b3,G:G41'],
['Gaussian KL calculation','Use 1/2(μ²+σ²−1−lnσ²) with σ as standard deviation.','Convert an explicitly supplied variance before substitution.','G:G37,G:G41'],
['Sampling for new generation','Fresh generation samples p(z) and passes it through the decoder.','Distinguish prior generation from encoder-conditioned reconstruction.','S:a17,G:G39']]);
put('autoencoders','reparameterisation',[
['Naive sampling breaks an ordinary path','A random draw is not exposed as a deterministic differentiable function of encoder parameters.','Explain the pathwise-gradient problem precisely.','S:b3'],
['Separate noise from parameters','Use z=μ+σε with ε drawn independently of encoder outputs.','Compute a fixed-noise latent sample.','G:G38,G:G41'],
['Derivatives conditional on ε','For a fixed draw, ∂z/∂μ=1 and ∂z/∂σ=ε.','Show how reconstruction gradients reach the encoder.','G:G38'],
['A stochastic estimator remains stochastic','Reparameterisation enables a gradient estimator without removing sampling randomness.','Avoid calling it a deterministic generative model.','S:b3,G:G41']]);
put('autoencoders','sae',[
['Wide dictionary versus narrow code','A wide sparse AE offers many candidate features while limiting usage per input.','Explain why a hidden dimension larger than input can still be useful.','S:a18,G:G40'],
['L1 activation penalty','The activation norm encourages a few or small active features.','Explain the effect of increasing λ and the reconstruction trade-off.','G:G42'],
['Feature as a decoder direction','One hidden coordinate corresponds to a dictionary/decoder column in the supplied convention.','Define what the feature is, not just its proposed topic name.','S:b3,G:G42'],
['Interpretability checks','Use high-activation inputs, held-out controls and interventions on feature directions.','Describe a concrete check and avoid guaranteeing causal interpretability.','S:b3,G:G42']]);
put('convolution','conv-mechanics',[
['Output-size floor formula','For dilation one: floor((N+2P−K)/S)+1.','Apply the formula separately to every convolution and pooling stage.','S:a19,G:G43'],
['Channel-aware kernel count','A standard layer has Cout(CinK²+1) trainable parameters with biases.','Count spatial kernel weights across all input and output channels.','S:a20,G:G44'],
['Locality and weight sharing','The same small kernel is used across positions instead of learning a full image-to-image matrix.','Give both explanations for parameter efficiency.','S:a21,G:G48'],
['Pooling changes geometry, not kernel parameters','Ordinary max pooling selects maxima and normally has no trainable kernel weights.','Track shape and distinguish activations from learned parameters.','S:a19,G:G47']]);
put('convolution','efficient-conv',[
['Pointwise channel mixing','A 1×1 convolution mixes channels at a spatial position.','Explain channel bottlenecks without claiming it directly combines adjacent positions.','G:G46'],
['Depthwise plus pointwise weights','The comparable weight counts are K²CinCout versus K²Cin+CinCout.','Omit or include biases consistently in the comparison.','G:G45'],
['Receptive-field growth','Stacked local operators allow an output to depend on a larger input region.','Distinguish receptive-field size from feature-map dimensions.','G:G48'],
['Efficiency has multiple dimensions','Parameter storage, operation count, memory traffic and latency need not change proportionally.','Avoid inferring actual device speed only from a weight count.','G:G48']]);
put('vision','cnn-family',[
['Depth and multi-scale branches','VGG stacks small kernels; Inception combines differently sized processing paths.','Explain the mechanism rather than listing model names.','G:G54'],
['Residual addition versus concatenation','ResNet adds a residual update; DenseNet concatenates earlier maps.','State the distinct reuse operations accurately.','G:G49'],
['Compact channel operations','MobileNet, ShuffleNet and SENet use different efficient or adaptive channel mechanisms.','Compare separable filtering, shuffling and channel gating.','G:G48,G:G54'],
['Architecture scaling trade-offs','EfficientNet balances width, depth and resolution; NAS searches a specified space and objective.','Explain why model size alone is not a complete architecture criterion.','G:G54']]);
put('vision','vision-transformers',[
['ViT patch representation','Flattened image patches are embedded into tokens with position information.','Describe the image-to-sequence conversion and class-token use.','G:G51'],
['Local windows and shifted windows','Swin constrains attention locally and shifts partitions to connect previous windows.','Explain cross-window information flow.','G:G52'],
['Distillation and inductive biases','DeiT uses distillation; ConViT introduces soft convolutional bias; ConvNeXt modernises CNN design.','Compare the design decisions, not just their dates.','G:G54'],
['Masked image self-supervision','MAE hides patches and reconstructs missing image content.','Identify where targets come from and how this differs from labelled recognition.','G:G60']]);
put('vision','detection',[
['Classification, boxes and masks','Recognition tasks require different outputs: image labels, boxes, pixel categories or object instances.','Distinguish semantic from instance segmentation.','G:G53'],
['Region proposal evolution','R-CNN repeats region feature extraction; Fast R-CNN shares maps; Faster R-CNN learns proposals.','Identify the RPN and its relationship to shared features.','G:G50,G:G53'],
['Single-stage versus region-based detection','SSD and YOLO predict detections directly in a single-stage pipeline.','Contrast proposal mechanisms and outputs without assuming one method always wins.','G:G53'],
['Dense decoders and overlap handling','U-Net produces dense predictions; NMS removes redundant overlapping boxes; Mask R-CNN adds instance masks.','Match each mechanism to the actual output problem.','G:G53']]);
put('generative','families',[
['A distribution and a sampling story','Generative modelling must specify what is modelled and how a sample is obtained.','Compare VAE prior decoding with GAN noise-to-sample generation.','G:G57,G:G59'],
['Autoregressive factorisation','A joint distribution is a product of conditionals on earlier variables.','Write the factorisation and sampling order.','G:G55'],
['Flows and invertibility','Exact change-of-variables likelihood uses an invertible map and a Jacobian correction.','Explain why a general lossy bottleneck does not meet this condition.','G:G56'],
['Diffusion and latent diffusion','A learned reverse denoising process can operate in pixels or a compressed latent space.','Explain the latent-space efficiency idea and decoder’s role.','G:G58,G:G59']]);
put('generative','generation-links',[
['Compression to latent generation','AE representations become a component of VAE or latent-diffusion pipelines.','Separate representation learning from a complete sampling model.','G:G39,G:G58'],
['Causal masking across modalities','Pixel autoregression and next-token language modelling share a no-future-information constraint.','Explain why seeing a target-dependent future input would leak information.','G:G55,G:G69'],
['Training-objective differences','Adversarial training, ELBO optimisation, exact flow likelihood and denoising objectives differ.','Compare mechanisms without assigning the VAE loss to every generator.','G:G59'],
['Denoising is not automatically diffusion','A robust denoising AE and a full probabilistic reverse diffusion chain are distinct constructions.','Identify targets, corruption and the complete generation process.','G:G60']]);
put('language','tokens',[
['Discrete units before dense vectors','A tokenizer maps text to units and IDs; an embedding table maps IDs to vectors.','Do not treat a token as necessarily a complete word.','G:G62'],
['Count BPE pair frequencies','Training repeatedly selects adjacent frequent pairs under stated boundaries and tie-breaking rules.','Count occurrences with corpus word frequencies.','G:G61,G:G65'],
['Apply learned merge priorities','Inference starts from small units and applies stored merge rules.','Work through the trained rules without retraining on a test word.','G:G65'],
['Vocabulary depends on conventions','Boundary markers, pretokenisation and tie breaks affect a toy BPE result.','State the conventions supplied by the question.','G:G61,G:G65']]);
put('language','embeddings',[
['One-hot geometry limitation','Distinct one-hot IDs are orthogonal and do not encode learned semantic similarity.','Explain what is missing beyond word identity.','G:G66'],
['Embedding table lookup','A V×d table has one d-dimensional row per vocabulary item.','Show that multiplying a one-hot row selects its matching row.','G:G62'],
['Distributional context and co-occurrence','Context counts can provide semantic evidence and be factorised into compact representations.','Explain sparsity, scale and updating limits of very large count matrices.','G:G66'],
['Similarity needs interpretation','Dense-vector cosine similarity probes learned geometry but is not a universal semantic guarantee.','Interpret analogies or clusters with appropriate empirical checks.','G:G66,G:G34']]);
put('language','word2vec',[
['Skip-gram direction','The centre word is used to predict context words.','State the conditional prediction direction.','G:G63'],
['CBOW direction','A bag of nearby context words predicts the centre word.','Contrast it with skip-gram and note bag-of-context order limitations.','G:G63'],
['Efficient training objectives','Negative sampling updates selected positive/negative words; hierarchical softmax is another strategy.','Explain the computational saving without claiming identical full-softmax evaluation.','G:G64'],
['Static versus contextual vectors','A static word vector is reused across contexts; a Transformer representation depends on its sequence.','Explain the limitation that motivates contextual attention.','G:G66,G:G72']]);
put('attention','qkv',[
['Query, key and value roles','Queries seek, keys match, and values contain retrieved information.','Give all three roles with an explicit lookup analogy.','S:a22,G:G72'],
['Score matrix shapes','QKᵀ has one row per query and one column per key.','Track nq×dk, nk×dk and nk×dv through the operation.','G:G71'],
['Row-wise weighted retrieval','Apply softmax over keys for each query, then multiply the weights by V.','Compute weights and a weighted value vector, not a weighted key vector.','G:G67,G:G71'],
['Self versus cross-attention','Q,K,V share a sequence in self-attention; cross-attention separates query and memory sequences.','State the origin of the matrices in each setting.','S:a23,G:G72']]);
put('attention','mask',[
['Mask before normalisation','Future scores j>i are removed before softmax, usually with −∞.','Identify the upper-triangular excluded entries.','S:a24,S:b2'],
['A zero score still has positive mass','exp(0)=1, so setting a forbidden score to zero does not exclude it.','Explain why the zero-score shortcut leaks future information.','G:G69'],
['Sample-specific scaling convention','The supplied long question omits 1/√d even though the general formula uses it.','Follow the stated convention in the exact numerical calculation.','S:b2,G:G71'],
['Quadratic dense score count','Every query–key pair contributes a score when using dense self-attention.','Compute n² counts and context-length scaling factors.','S:b2,G:G68']]);
put('attention','transformer-block',[
['Multiple learned heads','Different projections provide separate learned subspaces or attention patterns.','Explain why more heads are useful rather than merely duplicating one fixed pattern.','S:a25,G:G72'],
['Position information','Content-only attention does not identify absolute ordering by itself.','Explain why positional encodings or embeddings are supplied.','G:G72'],
['Residual and feedforward components','Attention sublayers are composed with residual paths, normalisation and position-wise transformations.','Describe the block’s information flow and distinguish residual addition from concatenation.','G:G49,G:G72'],
['Encoder–decoder temporal context','Earlier attention retrieves encoder-state context during decoding; teacher forcing supplies prior true tokens in training.','Distinguish training information from autoregressive inference.','G:G72']]);
put('attention','objectives',[
['Causal decoder language modelling','A decoder-only model predicts next tokens from earlier context.','Write the autoregressive likelihood and explain masking.','G:G70,G:G55'],
['Bidirectional masked modelling','An encoder-only masked LM uses visible surrounding context to recover hidden tokens.','Compare the objective with causal next-token prediction.','G:G70'],
['Text-to-text encoder–decoder','The input encoder and causal output decoder are linked by cross-attention.','Identify which side is bidirectional and which side generates causally.','G:G70,G:G72'],
['Original BERT auxiliary task','The supplied slides also discuss next-sentence prediction with [CLS] and [SEP].','Describe its classification purpose without assuming all masked LMs use that auxiliary task.','G:G70']]);
const kind={S:'sample',T:'teacher',G:'generated',Q:'quiz'};
function resolve(ref){const [code,id]=ref.split(':'),k=kind[code];const q=k==='sample'?[...EXAM_SHORT,...EXAM_LONG].find(q=>q.id===id):k==='teacher'?EXERCISES.find(q=>q.id===id):k==='generated'?PREDICTIONS.find(q=>q.id===id):k==='quiz'?QUIZ.find(q=>q.id===id):null;if(!q)return null;return {kind:k,id,q,label:k==='sample'?'Sample '+id.toUpperCase():k==='teacher'?'Teacher '+id.toUpperCase():k==='generated'?'AI-generated '+id:'AI quiz '+id,href:'#question/'+k+'/'+id};}
function points(topic,section){return sections[topic+':'+section]||[];}
function records(){return TOPICS.flatMap(t=>t.sections.flatMap(s=>points(t.id,s.id).map(p=>({...p,topic:t.id,section:s.id,title:s.title,key:t.id+':'+s.id+':'+p.id,source:s.source}))));}
window.KnowledgeMap={motivations,relations,sections,points,records,resolve};
})();
