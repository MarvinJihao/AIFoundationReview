# Foundations — AI Exam Studio · v4

An English-first, offline exam-preparation website for University of Bristol SEMTM0051 Foundations of AI, built from the files recovered from the referenced conversation.

## New in v4

- A modeless **Formula sheet** drawer is available from the lower-right corner on every page. Expand or collapse it while keeping the question visible. Search all 11 formula sections, or open the original sample PDF at page 6. The Exam room's Formula sheet button opens the same drawer.
- A separate **Study timer** supports 5/25/50/90-minute presets and a custom whole-minute duration from 1 to 360. Start, pause, continue and reset it from the floating panel or open its settings from the main settings dialog.
- The timer stores an absolute finish time, so changing page, reloading or closing/reopening does not pause a running timer. Paused time remains paused. Timer state is included in progress backups; old backups without a timer remain valid.
- The timer is a personal study aid, separate from the Exam room simulation and not an official exam time limit.

This downloadable version still saves progress locally. A separate cloud-enabled source package has been prepared with authenticated storage and conflict handling, but publication is currently blocked by the execution environment. Do not assume this local copy has cross-device cloud sync.

Run `node tests/validate-tools.cjs` for the formula/timer checks.

## Earlier v3 additions


- An apple.com-inspired visual system: white/soft-grey cards, black typography, blue actions, large whitespace and a compact translucent top navigation. The site remains an independent study tool.
- The course map now expands to **12 topics → 40 sections → 160 detailed knowledge/exam points**.
- Every topic explains **why it is introduced**. Each point states the knowledge to understand and the task an exam answer must perform.
- **22 explained topic relationships**, with a clickable relationship diagram and a readable relationship ledger. Links distinguish enabling, generalising, contrasting and other connections.
- Each detailed point links directly to a specific question. **159 exact-question routes** cover the 28 sample questions, 11 teacher exercises, 72 generated forecasts and 48 generated quiz checks. Every question page also links back to its relevant knowledge points.
- Use `Course mind map` → `160 exam points`, click a blue point or its Q link, or search the full explanations. Choose `Detailed outline` for a text-first view.
- The original forecasts retain visible **AI-GENERATED** tags. These are practice forecasts, not privileged knowledge of the future exam.
- Ready-made complete map SVG/PNG, topic-relationship SVG/PNG, and a detailed revision outline are included. Keep SVG exports beside `index.html` to preserve their relative question links.

## Earlier v2 additions


- A modern cool-white, deep-navy, indigo and violet card interface with a redesigned dashboard.
- **Course mind map**: six connected branches, all 12 recovered-course areas and 40 concepts, exam-solving procedures, pitfalls, sample-question links, zoom/pan, collapsible branches, concept search and a text outline.
- Download the complete mind map as SVG from its page. A ready-made SVG, PNG and detailed revision outline are also included in this folder.
- **Exam predictions**: 72 newly authored questions, comprising 48 short answers and 24 long answers. Each carries a visible **AI-GENERATED** tag, a worked answer and suggested marking points. Filter by topic, type and basis; switch between cards and a sortable table; save questions; write answers; track self-check points; export a filtered set.
- The original 48 auto-marked quiz questions are now explicitly labelled AI-generated too. Supplied teacher exercises and the sample paper retain separate labels.
- Existing version-1 progress backups remain compatible. Use the same browser and file location/origin, or import a backup when moving to a new location.

"Sample-aligned" means that a topic occurs in the supplied sample; "Coverage extension" means wider practice from the recovered notes. These are study forecasts, not an estimate or guarantee of the next exam's questions.

## Open the website

Extract the complete ZIP and open **index.html** in a modern browser. Keep the neighbouring files and the `sources` folder together. No installation, account, API key or internet connection is required.

For the most consistent saved progress and embedded PDF behaviour, run `node serve.js` from this folder and open **http://127.0.0.1:4173**. This optional server requires Node.js 18 or later and no packages. Stop it with Ctrl+C. Use the same browser and address each time to retain progress.

## What is included

- 12 topic areas covering regression/probabilities, optimisation, neural networks, backpropagation, PCA, ICA, autoencoders/VAEs/sparse AEs, convolution, vision architectures and detection, generative vision, tokenisation/embeddings, attention and language models.
- All 8 neural-network exercises and 3 backpropagation exercises from the two recovered exercise/solution sheets, with answer spaces, review markers and worked walkthroughs.
- All 25 sample short questions and all parts of the 3 long questions. Timed simulation and untimed study modes, supplied formula sheet, saved answers, self-marking rubrics, partial-credit score controls and best-two-of-three long-question scoring (maximum 70).
- 48 generated practice questions, per-topic practice records, missed-question review, and formula flashcards.
- Eight calculators: softmax/CE, backpropagation, causal attention, convolution, PCA, known linear mixing/unmixing, VAE latent sampling/KL, and gradient descent on the teacher's loss.
- Comparison tables, a sortable topic coverage table, notes, confidence ratings, section review tracking, progress backup/export/import, and an exam answer-record download.
- The 10 recovered original PDFs (195 pages), page-addressed PDF viewing and extracted-text search.

## Coverage limitation

The earlier chat states that 16 PDFs were uploaded. Only 10 attachments were recoverable in this Windows session; the `/mnt/data` mount was unavailable. **Six referenced PDFs remain missing. This is a verified 10-file build, not verified coverage of all 16 files.** The missing six titles and contents were not available, so no content has been attributed to them. The Source library exposes this limitation.

Recovered files:

1. 2026_sample_semtm0051.pdf — 6 pages
2. 2026_sample_semtm0051_ans.pdf — 9 pages
3. 2026_SEMTM0051_Con01_PCA.pdf — 17 pages
4. 2026_SEMTM0051_Con02_ICA.pdf — 8 pages
5. SEMTM0051.Week10.LVMs.pdf — 48 pages
6. SEMTM0051.Week11.LLMs.pdf — 42 pages
7. Solutions_to_the_exercises(4).pdf — 8 pages
8. Solutions_to_the_exercises(5).pdf — 6 pages
9. Week_04 - Neural Networks.pdf — 24 pages
10. Week_05 - Backpropagation.pdf — 27 pages

## Content and exam conventions

The original PDFs preserve exact wording, notation and diagrams. Study prose and exercise walkthroughs are rewritten; quizzes are generated practice, not additional official questions. The web exam transcribes the supplied mathematical inputs and mark allocation. Page references are physical PDF pages, not printed page labels; the mark-scheme PDF itself has inconsistent printed page totals.

The sample paper supplies **no exam duration**. The default 90-minute timer is explicitly a configurable practice setting. Scores are self-assessed; free-text answers are not automatically graded. Unmarked answers count as zero. Topic completion/confidence is self-reported and is not an exam-grade prediction.

At a ReLU kink the calculators use multiplier zero as a software convention, not an ordinary derivative. The attention default omits square-root scaling to match the sample question. The ICA demo uses a known mixing matrix and its inverse; it is not an implementation of FastICA. PCA uses a 2D positive-semidefinite covariance matrix. Standardisation and whitening are distinguished in the study notes. The sample formula sheet's Adam formula omits bias correction, as noted in the website.

Text extraction may lose equation structure and image-based content; one dense PDF extraction reported a complexity limit. The original PDFs remain intact and available alongside the search text. Use original-page viewing for figures and formal notation.

## Saved work

Progress is saved in browser local storage. It is specific to the browser and origin; private browsing, clearing browser data or moving file URLs can affect persistence. Use **Export progress** for a JSON backup and import it from the settings button. Exam answers and notes may be personal; backups contain them. No analytics or network services are used.

A timed exam's deadline is saved, so leaving the page or closing the browser does not pause it. Returning after the deadline submits saved answers. Study mode is untimed. Download the answer record before replacing an exam attempt.

## Validation

See `VALIDATION.md` for the checks and verification limits for v3. The portable arithmetic/content checks can be rerun with `node tests/validate.cjs`; they use only built-in Node modules. Run `node tests/validate-v2.cjs` for the question-bank and map checks. Run `node tests/validate-v3.cjs` for detailed-point, exact-question, relationship and navigation checks. Optional browser tests require Playwright and a browser (not needed to run the website).

This is an independent personal-study companion, not an official University of Bristol website. Keep the supplied teaching materials within the access permissions under which you received them.
