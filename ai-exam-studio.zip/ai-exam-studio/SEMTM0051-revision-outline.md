# Foundations of AI — Detailed exam knowledge map

10 recovered PDFs. Six referenced PDFs remain unavailable. Explanatory learning connections are not an official prescribed syllabus order.

## Regression & probability

### Why this topic is introduced

Before building a network, we need a precise learning problem: what is predicted, which parameters change, and what makes a prediction good? Regression introduces features and an objective; probability links and cross-entropy extend this language to classification.

### Connections

- Regression & probability → enables → Training & optimisation: A chosen empirical loss becomes the differentiable objective used by parameter updates.
- Regression & probability → generalises → Neural networks: A network replaces a fixed feature map with learned nonlinear feature composition.
- Regression & probability → initialises → Backpropagation: The task-specific loss determines the first backward row: squared error or cross-entropy.
- Regression & probability → normalises → Attention & Transformers: Row-wise softmax turns query–key scores into a probability-weighted mixture of values.

### Least squares and feature maps

A model is linear in its parameters when its prediction is a weighted sum of fixed features. It need not be linear in the original input. For y = a + b sin x + c cos x, use the row (1, sin x, cos x) in the design matrix. An intercept requires a column of ones. Squared-error fitting minimises the sum (or stated mean) of residual squares. A constant-only predictor is optimised by the mean of the targets: differentiating Σ(c − yᵢ)² gives 2Σ(c − yᵢ) = 0.

θ* = (XᵀX)⁻¹Xᵀy   when XᵀX is invertible
c* = (1/n) Σ yᵢ
Example: y = (2,4,6,8,10) ⇒ c* = 6

#### Constant least-squares predictor

The derivative of Σ(c−yᵢ)² is 2Σ(c−yᵢ), so the minimiser is the target mean.

**Exam task:** Identify the mean, calculate it, and evaluate residual squares if requested.

**Exact questions:** [Sample A1](index.html#question/sample/a1), [AI-generated G01](index.html#question/generated/G01)

#### Fixed feature maps

A model can be nonlinear in x while remaining linear in its unknown coefficients.

**Exam task:** Write an explicit feature row, including an intercept feature.

**Exact questions:** [Sample A3](index.html#question/sample/a3), [AI-generated G02](index.html#question/generated/G02)

#### Design-matrix shapes

One row corresponds to each observation; each column is one feature.

**Exam task:** State X, θ and y shapes before matrix multiplication.

**Exact questions:** [AI-generated G05](index.html#question/generated/G05), [Teacher NN1](index.html#question/teacher/nn1)

#### Normal equations and rank

The inverse formula requires XᵀX to be invertible; full column rank is the relevant condition.

**Exam task:** Build XᵀX and Xᵀy, check the determinant and verify fitted residuals.

**Exact questions:** [AI-generated G05](index.html#question/generated/G05)

Source: 2026_sample_semtm0051.pdf, physical PDF page 2

### Sigmoid, softmax and cross-entropy

A binary network produces an unrestricted logit f. Sigmoid maps it into (0,1), interpreted as P(y=1 | x). For mutually exclusive classes, softmax normalises a logit vector into positive probabilities summing to one. Larger logits give larger probabilities. Subtracting the maximum logit before exponentiation gives the same probabilities and prevents overflow. Natural logarithms are used throughout the supplied paper.

σ(f) = 1/(1 + exp(−f))
pᵢ = exp(aᵢ)/Σⱼ exp(aⱼ)
Binary CE = −y ln p − (1−y) ln(1−p)
Multiclass CE = −ln pᵧ

#### Logit to binary probability

Sigmoid maps an unrestricted score into (0,1).

**Exam task:** Explain why a real-valued logit is not itself a probability.

**Exact questions:** [Sample A6](index.html#question/sample/a6), [AI-generated G04](index.html#question/generated/G04)

#### Softmax normalisation

Exponentiate class logits and divide by their sum, separately for each example.

**Exam task:** Compute class probabilities and check that they sum to one.

**Exact questions:** [Sample A4](index.html#question/sample/a4), [Sample A5](index.html#question/sample/a5), [AI-generated G03](index.html#question/generated/G03)

#### Choose the observed-label loss

Binary CE uses y and 1−y; multiclass CE is the negative log probability of the correct class.

**Exam task:** Use natural logs and select p versus 1−p correctly.

**Exact questions:** [Sample A7](index.html#question/sample/a7), [AI-generated G03](index.html#question/generated/G03)

#### Stable softmax and shift invariance

Adding a common constant to logits does not change their probabilities.

**Exam task:** Justify subtracting the maximum logit before exponentiation.

**Exact questions:** [AI-generated G06](index.html#question/generated/G06), [AI quiz q5](index.html#question/quiz/q5)

Source: 2026_sample_semtm0051.pdf, physical PDF page 2

### Calculator-ready examples

For logits (1,1,0), exponentials are (e,e,1); the denominator is 2e+1. The probabilities are approximately (0.422,0.422,0.155) to three significant figures. For p=0.9, a positive target has loss −ln(0.9) ≈ 0.105, while a negative target has loss −ln(0.1) ≈ 2.303. A correct class prediction can still have a positive loss because the loss also rewards confidence.

softmax(1,1,0) ≈ (0.4223188, 0.4223188, 0.1553624)
σ(0)=½;  σ′(f)=σ(f)(1−σ(f))

#### Equal logits share probability

Identical class logits produce identical softmax probabilities.

**Exam task:** Calculate the supplied (1,1,0) vector before rounding.

**Exact questions:** [Sample A5](index.html#question/sample/a5), [AI quiz q3](index.html#question/quiz/q3)

#### Confidence changes the loss

A confident correct prediction has small CE; the same confidence on a wrong label has large CE.

**Exam task:** Compute both target cases for p=0.9 and explain the asymmetry.

**Exact questions:** [Sample A7](index.html#question/sample/a7), [AI quiz q4](index.html#question/quiz/q4)

#### Sigmoid sketch landmarks

The sigmoid is increasing, passes through (0,1/2), and approaches 0 and 1.

**Exam task:** Label midpoint and both asymptotes on a sketch.

**Exact questions:** [Sample A9](index.html#question/sample/a9), [AI quiz q6](index.html#question/quiz/q6)

#### Accuracy is not cross-entropy

Correct class labels can coexist with positive loss because correct-label probabilities are below one.

**Exam task:** Distinguish decision threshold, confidence and probabilistic loss.

**Exact questions:** [Teacher NN8](index.html#question/teacher/nn8), [AI-generated G18](index.html#question/generated/G18)

Source: 2026_sample_semtm0051_ans.pdf, physical PDF page 2
## Training & optimisation

### Why this topic is introduced

Writing a loss does not tell us how to find its parameters. Differentiation produces a direction for improvement, while gradient descent turns it into updates. Neural-network examples then reveal why local progress does not guarantee a globally best fit.

### Connections

- Regression & probability → enables → Training & optimisation: A chosen empirical loss becomes the differentiable objective used by parameter updates.
- Training & optimisation → trains → Neural networks: Gradient updates fit weights; network nonlinearity makes the optimisation landscape nonconvex.
- Backpropagation → supplies → Training & optimisation: Backprop computes a gradient; gradient descent, momentum or Adam decides the update.
- Training & optimisation → constrains → Vision architectures & detection: Architectures trade off parameter count, optimisation difficulty, generalisation and actual runtime.

### Gradient descent and training vocabulary

Gradient descent subtracts the learning rate times the gradient. A very small learning rate produces slow progress; a very large one can overshoot, oscillate or diverge. An epoch is one pass through the dataset. A minibatch gives one gradient estimate and one update; 10,000 observations in batches of 100 give 100 updates per epoch. For a summed loss, gradients add; for a mean loss, divide the sum by the number of observations. Keep this convention consistent.

θ ← θ − η∇L(θ)
∇(Σᵢ ℓᵢ) = Σᵢ∇ℓᵢ
Updates/epoch = ceil(N/B), if the last incomplete batch is retained

#### Direction and learning rate

Gradient descent subtracts η∇L. Its magnitude controls progress and stability.

**Exam task:** Explain small-step slowness and large-step overshoot.

**Exact questions:** [Sample A2](index.html#question/sample/a2), [AI-generated G08](index.html#question/generated/G08)

#### Epoch versus update

An epoch is one dataset pass; a minibatch normally produces one update.

**Exam task:** Count updates, explicitly stating treatment of an incomplete batch.

**Exact questions:** [Sample A13](index.html#question/sample/a13), [AI-generated G07](index.html#question/generated/G07)

#### Sum versus mean gradients

Differentiation commutes with summation; averaging losses averages their gradients.

**Exam task:** Keep the loss reduction consistent throughout a backward pass.

**Exact questions:** [AI-generated G21](index.html#question/generated/G21)

#### Momentum versus Adam

Momentum accumulates gradients; Adam also tracks a second moment to rescale coordinates.

**Exam task:** Use the formula-sheet convention and state whether bias correction is omitted.

**Exact questions:** [AI-generated G10](index.html#question/generated/G10), [AI-generated G12](index.html#question/generated/G12)

Source: Week_05 - Backpropagation.pdf, physical PDF page 19

### Why a decreasing loss can still disappoint

The lecture network fθ(x)=|x−θ|−3 is trained at x=−1 and x=1. With regression targets −1 and 1, its objective has a global minimum at θ=−3 with loss 0, and a strict local minimum at θ=3 with loss 8. Both have zero derivative. Starting from −2 or 2 with η=0.2, the iterates approach different minima even though each loss decreases at every update. Stationarity alone does not imply a global minimum for a neural network.

L(θ) = 2(θ+3)²              for θ ≤ −1
       2(θ+1)² + 8         for −1 < θ < 1
       2(θ−3)² + 8         for θ ≥ 1
−2 → −2.8 → −2.96;  losses 2 → 0.08 → 0.0032
 2 →  2.8 →  2.96;  losses 10 → 8.08 → 8.0032

#### Stationary is not globally optimal

A zero derivative may occur at a poor local minimum, saddle or other stationary point.

**Exam task:** Use the teacher’s minima at −3 and 3 as a concrete counterexample.

**Exact questions:** [Teacher NN6](index.html#question/teacher/nn6), [AI-generated G11](index.html#question/generated/G11)

#### Different initialisations, different basins

The same update rule can approach minima with different objective values.

**Exam task:** Calculate iterates and their losses from both initial values.

**Exact questions:** [Teacher NN6](index.html#question/teacher/nn6), [AI-generated G11](index.html#question/generated/G11)

#### Piecewise derivative selection

Different parameter regions have different quadratic formulas.

**Exam task:** Select the current region before evaluating a gradient.

**Exact questions:** [Teacher NN6](index.html#question/teacher/nn6), [AI quiz q10](index.html#question/quiz/q10)

#### Monotone improvement is local evidence

Loss can decrease at every step while converging to a suboptimal loss of 8.

**Exam task:** Explain why a descending sequence does not prove global optimality.

**Exact questions:** [AI-generated G11](index.html#question/generated/G11), [AI quiz q9](index.html#question/quiz/q9)

Source: Week_04 - Neural Networks.pdf, physical PDF page 18

### Practical fitting and generalisation

Different random initialisations can reach different fits. Minibatch noise can sometimes move away from a poor region, but it provides no general guarantee of finding a global optimum. Adding hidden units changes both expressiveness and optimisation; it also provides no automatic guarantee. Automatic differentiation computes derivatives of your chosen computation; it does not choose a good loss or guarantee a good solution. Diagnose underfitting when training and validation losses both remain high and close together; overfitting is indicated by a much better training fit than validation fit. Select model choices using validation data and reserve the test set for evaluation.

#### Initialisation and architecture heuristics

Restarts and additional capacity may help, but supply no universal guarantee.

**Exam task:** Assess a claim rather than asserting that width always fixes training.

**Exact questions:** [AI-generated G12](index.html#question/generated/G12)

#### What minibatch noise can and cannot do

A minibatch gradient may avoid full-gradient cancellation, but can also be zero.

**Exam task:** Explain why SGD need not escape every nonglobal stationary point.

**Exact questions:** [AI-generated G12](index.html#question/generated/G12)

#### Underfitting diagnostic

High, similar training and validation losses indicate inadequate fit or optimisation.

**Exam task:** Describe both curves and a plausible cause.

**Exact questions:** [Sample A14](index.html#question/sample/a14), [AI-generated G09](index.html#question/generated/G09)

#### Generalisation gap

Low training loss with a much higher validation loss is consistent with overfitting.

**Exam task:** Use validation for choices and preserve the test set for evaluation.

**Exact questions:** [AI-generated G09](index.html#question/generated/G09)

Source: Week_04 - Neural Networks.pdf, physical PDF page 21
## Neural networks

### Why this topic is introduced

A linear model can only combine the features it is given. If fixed features cannot distinguish inputs or express the required boundary, learning the features themselves becomes useful. Affine layers and nonlinearities create this trainable composition.

### Connections

- Regression & probability → generalises → Neural networks: A network replaces a fixed feature map with learned nonlinear feature composition.
- Training & optimisation → trains → Neural networks: Gradient updates fit weights; network nonlinearity makes the optimisation landscape nonconvex.
- Neural networks → requires → Backpropagation: The forward composition defines which local derivatives must be chained and reused.
- Neural networks → implements → Autoencoders & latent models: Encoder and decoder are neural feature maps trained by reconstruction-based losses.
- Neural networks → specialises → Convolution & image geometry: Local connectivity and spatial weight sharing constrain an otherwise general learned affine operation.

### Affine layers and why nonlinearities matter

Inputs and activations in the supplied network notes are rows. Each weight matrix has one row per incoming coordinate and one column per outgoing coordinate. An affine layer is a linear transformation plus a bias. Two affine layers collapse into one affine transformation if there is no intervening nonlinearity. With ReLU inserted, slopes can change across boundaries, so the resulting function need not be affine.

x ∈ ℝ¹ˣᵈ; W ∈ ℝᵈˣᵐ; b ∈ ℝ¹ˣᵐ
a = xW + b;  h = ReLU(a)
(xA+b)C+d = x(AC)+(bC+d)
ReLU(t)=max(0,t)

#### Row-vector weight convention

W has one row per incoming coordinate and one column per output unit.

**Exam task:** Check xW+b shapes and explain a matrix entry.

**Exact questions:** [Teacher NN1](index.html#question/teacher/nn1), [AI-generated G13](index.html#question/generated/G13)

#### Bias placement

Each output coordinate receives its own bias after the weighted sum.

**Exam task:** Count one bias per unit, not per input connection.

**Exact questions:** [Sample A10](index.html#question/sample/a10), [AI-generated G13](index.html#question/generated/G13)

#### Collapsing affine compositions

Two affine layers combine as xAC+(bC+d).

**Exam task:** Give the effective weight and bias, including both original biases.

**Exact questions:** [Teacher NN2](index.html#question/teacher/nn2), [AI-generated G14](index.html#question/generated/G14)

#### Why nonlinearities matter

An intervening nonlinearity can change slopes and increase the function class.

**Exam task:** Demonstrate non-affinity using a piecewise restriction, not just one changed value.

**Exact questions:** [Sample A11](index.html#question/sample/a11), [Teacher NN2](index.html#question/teacher/nn2)

Source: Week_04 - Neural Networks.pdf, physical PDF page 2

### Read an architecture and count its parameters

For widths d₀,d₁,…,dL, layer r has dᵣ₋₁dᵣ weights and dᵣ biases. The input is not counted as a layer in these notes. A 2→5→7→3 network therefore has depth 3 and 81 trainable parameters. A 3→4→2 network has 26 parameters, versus 8 for a single 3→2 affine map. Hidden layers learn features of earlier features; nonlinear composition supports hierarchies that can represent complicated functions efficiently.

P = Σᵣ (dᵣ₋₁dᵣ+dᵣ)
2→5→7→3: (10+5)+(35+7)+(21+3)=81

#### Layer widths and depth

The supplied convention counts hidden and output layers but excludes the input.

**Exam task:** Translate an architecture into ordered widths.

**Exact questions:** [Teacher NN1](index.html#question/teacher/nn1), [AI-generated G13](index.html#question/generated/G13)

#### Weight and bias shapes

A d→m affine layer has a d×m matrix and a 1×m bias row.

**Exam task:** State all matrix and hidden-row dimensions.

**Exact questions:** [Teacher NN1](index.html#question/teacher/nn1)

#### Total parameter count

Sum dᵣ₋₁dᵣ+dᵣ across layers.

**Exam task:** Separate weights and biases before adding.

**Exact questions:** [Sample A10](index.html#question/sample/a10), [AI-generated G13](index.html#question/generated/G13)

#### Hierarchical feature efficiency

Nonlinear layers build features of features, enabling useful compositional representations.

**Exam task:** Explain what depth adds beyond multiplying more linear matrices.

**Exact questions:** [Sample A8](index.html#question/sample/a8), [Sample A11](index.html#question/sample/a11)

Source: Week_04 - Neural Networks.pdf, physical PDF page 11

### The lecture’s numerical forward pass

With W₁=[[1,2,−1],[−1,0,1]], b₁=(0,1,0), W₂=(2,−1,½)ᵀ and b₂=−1, the input x=(1,2) produces preactivations (−1,3,1), hidden activations (0,3,1), and output −3.5. Hidden activations are nonnegative here, but the final output can be negative because the output weights and bias are unrestricted. At the exercise input x=(2,0), the same network produces (2,5,−2), then (2,5,0), then −2.

a₁=xW₁+b₁;  ϕ₁=ReLU(a₁);  f=ϕ₁W₂+b₂
x=(1,2) ⇒ f=−7/2
x=(2,0) ⇒ f=−2; squared loss at y=1 is 9

#### Compute preactivations first

An affine sum and its nonlinear activation are different saved quantities.

**Exam task:** Show a₁ before applying ReLU componentwise.

**Exact questions:** [Teacher NN3](index.html#question/teacher/nn3), [AI-generated G17](index.html#question/generated/G17)

#### Inactive versus active ReLUs

Negative preactivations become zero; positive ones pass unchanged.

**Exam task:** Identify which hidden feature is inactive.

**Exact questions:** [Teacher NN3](index.html#question/teacher/nn3), [AI-generated G17](index.html#question/generated/G17)

#### A signed output from nonnegative hidden units

The final weights and bias can be negative, and the output is not automatically rectified.

**Exam task:** Compute f without adding an unstated output activation.

**Exact questions:** [Teacher NN3](index.html#question/teacher/nn3)

#### Task-dependent output interpretation

A scalar can be a regression prediction or a binary logit, leading to different losses.

**Exam task:** Calculate regression SSE and sigmoid CE for the same forward output.

**Exact questions:** [Teacher NN3](index.html#question/teacher/nn3), [AI-generated G17](index.html#question/generated/G17)

Source: Week_04 - Neural Networks.pdf, physical PDF page 10

### Build functions and separate XOR

A ReLU turns on when its affine argument crosses zero. Weighted sums of shifted ReLUs can construct piecewise-linear functions. The XOR network uses the features ReLU(x₁−x₂) and ReLU(x₂−x₁), with output score equal to their sum minus ½. It separates the four Boolean XOR inputs even though a single affine decision boundary cannot. Scaling that score by α>0 leaves labels unchanged while changing probabilities and loss.

U(x)=2 ReLU(x+1)−4 ReLU(x)+2 ReLU(x−1)
U(x)=0 outside [−1,1], 2(x+1) on [−1,0], 2(1−x) on [0,1]
fXOR=ReLU(x₁−x₂)+ReLU(x₂−x₁)−½
Summed XOR logistic loss = 4 ln(1+exp(−α/2))

#### Breakpoints and slopes

An affine ReLU changes its formula where its preactivation is zero.

**Exam task:** Solve the breakpoint and sketch both linear pieces.

**Exact questions:** [Sample A12](index.html#question/sample/a12), [AI-generated G15](index.html#question/generated/G15)

#### Constructing a piecewise-linear tent

Weighted shifted ReLUs add and cancel slopes in chosen intervals.

**Exam task:** Give a piecewise function and network parameters that realise it.

**Exact questions:** [Teacher NN7](index.html#question/teacher/nn7), [AI-generated G18](index.html#question/generated/G18)

#### XOR via learned nonlinear features

Two ReLU difference features can separate the four XOR examples.

**Exam task:** List scores and predicted classes, then interpret positive score scaling.

**Exact questions:** [Teacher NN8](index.html#question/teacher/nn8)

#### ReLU at zero

Its left derivative is 0 and right derivative is 1. A software multiplier is a convention.

**Exam task:** Distinguish an ordinary derivative from a computational choice.

**Exact questions:** [Teacher NN5](index.html#question/teacher/nn5), [AI quiz q14](index.html#question/quiz/q14)

Source: Week_04 - Neural Networks.pdf, physical PDF page 14
## Backpropagation

### Why this topic is introduced

A network may have thousands of shared intermediate calculations and millions of parameters. Differentiating every parameter from scratch repeats work. Backpropagation reuses the chain rule, carrying loss sensitivities backward through the saved forward computation.

### Connections

- Regression & probability → initialises → Backpropagation: The task-specific loss determines the first backward row: squared error or cross-entropy.
- Neural networks → requires → Backpropagation: The forward composition defines which local derivatives must be chained and reused.
- Backpropagation → supplies → Training & optimisation: Backprop computes a gradient; gradient descent, momentum or Adam decides the update.
- Backpropagation → trains → Autoencoders & latent models: Reconstruction gradients train encoders; VAE reparameterisation restores a pathwise gradient through sampled latents.
- Backpropagation → trains → Attention & Transformers: Attention is a differentiable composition whose parameters can be learned from token losses.

### Remaining-loss functions and reuse

Jᵣ(u) means the loss obtained by starting from a hypothetical preactivation u at layer r and performing the remaining operations. Hold the target and later parameters fixed when differentiating u. The backward row δᵣ=∇Jᵣ(aᵣ) measures the loss sensitivity to that preactivation. Calculate it once and reuse it for all incoming weights, the bias, and the preceding layer. Save the preactivations and activations during the forward pass.

δᵣ = ∂L/∂aᵣ
∇Wᵣ L = ϕᵣ₋₁ᵀ δᵣ      (outer product)
∇bᵣ L = δᵣ
δᵣ₋₁ = (δᵣ Wᵣᵀ) ⊙ 1[aᵣ₋₁>0]

#### Remaining-loss function Jᵣ

Jᵣ starts at a hypothetical preactivation while holding target and later parameters fixed.

**Exam task:** Define its argument and identify which quantities are held fixed.

**Exact questions:** [Teacher BP1](index.html#question/teacher/bp1), [AI-generated G24](index.html#question/generated/G24)

#### Backward row δᵣ

The row is the loss sensitivity to the current preactivation.

**Exam task:** State its shape before propagating it.

**Exact questions:** [AI-generated G24](index.html#question/generated/G24)

#### Outer-product weight gradient

Incoming feature transpose times δ produces a matrix matching W.

**Exam task:** Calculate xᵀδ entrywise and verify dimensions.

**Exact questions:** [AI-generated G19](index.html#question/generated/G19), [Teacher BP1](index.html#question/teacher/bp1)

#### Bias gradient reuse

A bias enters its preactivation with derivative one.

**Exam task:** Reuse δ as the bias gradient instead of recomputing a chain.

**Exact questions:** [AI-generated G19](index.html#question/generated/G19), [AI-generated G24](index.html#question/generated/G24)

Source: Week_05 - Backpropagation.pdf, physical PDF page 11

### Start the backward pass with the correct loss

For squared loss (f−y)², the initial derivative is 2(f−y). For binary cross-entropy after sigmoid, the derivative with respect to the logit is p−y. For softmax cross-entropy, subtract the target one-hot vector from the probability row. The latter two expressions already include differentiation through sigmoid or softmax; multiplying by those derivatives again is a common error.

Regression: δL = 2(f−y)
Binary:     δL = p−y
Multiclass: δL,k = pₖ−1[k=y]

#### Squared-error initialisation

For the exact loss (f−y)², the output derivative is 2(f−y).

**Exam task:** Retain the factor 2; do not silently introduce a half.

**Exact questions:** [Sample B1](index.html#question/sample/b1), [Teacher BP1](index.html#question/teacher/bp1)

#### Binary CE initialisation

After sigmoid and CE, the derivative with respect to the logit simplifies to p−y.

**Exam task:** Avoid multiplying by sigmoid derivative again.

**Exact questions:** [Teacher BP2](index.html#question/teacher/bp2), [AI-generated G04](index.html#question/generated/G04)

#### Multiclass CE initialisation

Subtract the target one-hot vector from the probability row.

**Exam task:** Retain negative target-class entries.

**Exact questions:** [Teacher BP3](index.html#question/teacher/bp3), [AI-generated G22](index.html#question/generated/G22)

#### Batch reduction

Per-example gradients combine by the same sum or mean used in the loss.

**Exam task:** Explain how an averaged objective changes the gradient magnitude.

**Exact questions:** [AI-generated G21](index.html#question/generated/G21)

Source: Week_05 - Backpropagation.pdf, physical PDF page 18

### The scalar chain-rule example

The notes use x=2, y=−2, w₁=1,b₁=1,w₂=2,b₂=−1,w₃=−1,b₃=2. The forward values are a₁=3, ϕ₁=3, a₂=5, ϕ₂=5, f=−3 and L=1. Work backward: δ₃=−2; δ₂=(−2)(−1)=2; δ₁=(2)(2)=4. Each weight gradient is the incoming activation times its backward value.

∂L/∂(b₁,w₁,b₂,w₂,b₃,w₃) = (4,8,2,6,−2,−10)

#### Save the scalar forward chain

The loss depends on a sequence of affine and ReLU operations.

**Exam task:** List every intermediate before differentiation.

**Exact questions:** [AI-generated G24](index.html#question/generated/G24)

#### Local derivatives multiply along paths

Each affine operation contributes its weight; ReLU contributes its saved gate.

**Exam task:** Work backward using the chain rule in reverse computational order.

**Exact questions:** [AI-generated G24](index.html#question/generated/G24)

#### One sensitivity, multiple parameter gradients

A layer’s backward value is reused for both its bias and incoming weights.

**Exam task:** Multiply by the layer input for a weight gradient.

**Exact questions:** [AI-generated G19](index.html#question/generated/G19)

#### Differentiate before updating

All sensitivities must refer to the same forward parameter setting.

**Exam task:** Explain why early updates invalidate a manual backward pass.

**Exact questions:** [Teacher BP1](index.html#question/teacher/bp1), [AI-generated G23](index.html#question/generated/G23)

Source: Week_05 - Backpropagation.pdf, physical PDF page 2

### Vector example and zero gradients

For the lecture network at x=(2,0), y=1, the output is −2, so δ₂=−6. The output weight gradient is (−12,−30,0)ᵀ. Multiplying the backward row by W₂ᵀ gives (−12,6,−3); applying the saved ReLU mask (1,1,0) gives δ₁=(−12,6,0). The first-layer gradient has first row (−24,12,0) and second row zero. The third column vanishes because a hidden unit is inactive; the second row vanishes because x₂=0. These are different causes.

∇W₁L = [[−24,12,0],[0,0,0]]
∇b₁L = (−12,6,0)
∇W₂L = (−12,−30,0)ᵀ;  ∇b₂L = −6

#### Sum downstream contributions

Multiplying δᵣ by Wᵣᵀ adds the contributions of all downstream coordinates.

**Exam task:** Show separate output contributions before adding when requested.

**Exact questions:** [Teacher BP3](index.html#question/teacher/bp3), [AI-generated G24](index.html#question/generated/G24)

#### Gate from preactivation signs

The gate depends on a, not the sign of a gradient coordinate.

**Exam task:** Pass a negative gradient through a positive-preactivation unit.

**Exact questions:** [AI-generated G20](index.html#question/generated/G20), [Teacher BP3](index.html#question/teacher/bp3)

#### Two different causes of zeros

An inactive hidden unit zeros a column; a zero input coordinate zeros a weight-gradient row.

**Exam task:** Explain the row and column zeros separately.

**Exact questions:** [Teacher BP1](index.html#question/teacher/bp1), [Sample B1](index.html#question/sample/b1)

#### Simultaneous parameter update

Compute all gradients at the saved parameters and then apply each update.

**Exam task:** Give the updated matrix entries and biases with a stated η.

**Exact questions:** [Teacher BP1](index.html#question/teacher/bp1), [AI-generated G23](index.html#question/generated/G23)

Source: Solutions_to_the_exercises(5).pdf, physical PDF page 3

### Optional derivations: chain rule to logits

The multivariable chain rule sums one contribution from each downstream coordinate. An affine map supplies its weight as the local derivative; ReLU supplies its gate. For binary loss, ∂ℓ/∂p=(p−y)/(p(1−p)), which cancels σ′=p(1−p). For multiclass loss, write −aᵧ+ln Σ exp(aⱼ); differentiating gives pₖ−1[k=y]. Backpropagation reuses shared computations and costs on the same order as a forward evaluation, rather than running a separate complete calculation for every parameter.

∂L/∂uⱼ = Σₖ (∂L/∂vₖ)(∂vₖ/∂uⱼ)
∂softmax(a)ᵢ/∂aⱼ = pᵢ(1[i=j]−pⱼ)

#### Multivariable chain rule

A coordinate sensitivity sums the contributions of every downstream coordinate.

**Exam task:** Derive the row recurrence instead of assuming elementwise multiplication alone.

**Exact questions:** [AI-generated G24](index.html#question/generated/G24)

#### Sigmoid–CE cancellation

The CE probability derivative and σ′ factors cancel to give p−y.

**Exam task:** Specify that the result differentiates with respect to the logit.

**Exact questions:** [Teacher BP2](index.html#question/teacher/bp2), [AI-generated G04](index.html#question/generated/G04)

#### Softmax–CE derivative

Write the loss as −aᵧ+logsumexp(a) and differentiate.

**Exam task:** Obtain pₖ−1[k=y] with the correct target coordinate.

**Exact questions:** [AI-generated G06](index.html#question/generated/G06), [Teacher BP3](index.html#question/teacher/bp3)

#### Computational reuse

Reverse-mode differentiation shares intermediate sensitivities across parameter gradients.

**Exam task:** Explain efficiency relative to separately repeating a full chain for each parameter.

**Exact questions:** [AI-generated G24](index.html#question/generated/G24)

Source: Week_05 - Backpropagation.pdf, physical PDF page 23
## Principal component analysis

### Why this topic is introduced

High-dimensional measurements can be redundant or vary mainly along a few directions. Before using nonlinear networks, PCA supplies a transparent linear representation: rotate into variance directions, retain a small subspace and quantify what reconstruction loses.

### Connections

- Principal component analysis → contrasts → Independent component analysis: PCA decorrelates with second-order information; ICA seeks stronger independence using non-Gaussian structure.
- Principal component analysis → motivates → Autoencoders & latent models: A linear reconstruction subspace suggests learning a nonlinear encoder and decoder.

### From linear systems to eigendirections

A square matrix is invertible exactly when its determinant is nonzero. For [[a,b],[c,d]], det=ad−bc. An eigenvector e≠0 satisfies Ae=λe: the matrix scales that direction. Solve det(A−λI)=0 for eigenvalues, then solve (A−λI)e=0 for eigenvectors. The example [[2,1],[1,2]] has eigenvalues 3 and 1 and unit eigenvectors (1,1)/√2 and (1,−1)/√2.

A=[[2,1],[1,2]]
det(A−λI)=(2−λ)²−1=(λ−3)(λ−1)
A=PDPᵀ; P=(1/√2)[[1,1],[1,−1]], D=diag(3,1)

#### Invertibility and determinant

A square matrix with zero determinant has no inverse.

**Exam task:** Check this before a normal-equation or unmixing inverse.

**Exact questions:** [AI-generated G05](index.html#question/generated/G05), [AI-generated G31](index.html#question/generated/G31)

#### Characteristic equation

Eigenvalues satisfy det(A−λI)=0 for a nonzero eigenvector.

**Exam task:** Expand the 2×2 determinant and solve for λ.

**Exact questions:** [AI-generated G29](index.html#question/generated/G29)

#### Normalised loading directions

Solve (A−λI)e=0 and normalise the direction.

**Exam task:** State unit eigenvectors and recognise sign ambiguity.

**Exact questions:** [AI-generated G25](index.html#question/generated/G25), [AI-generated G29](index.html#question/generated/G29)

#### Symmetric spectral decomposition

A real symmetric covariance matrix has an orthonormal eigenbasis.

**Exam task:** Write Σ=PDPᵀ and distinguish P from D.

**Exact questions:** [AI-generated G29](index.html#question/generated/G29)

Source: 2026_SEMTM0051_Con01_PCA.pdf, physical PDF page 5

### Centre first, then measure joint variation

PCA is an unsupervised change of representation. Subtract the feature means before calculating covariance. The sample covariance uses n−1 in the denominator in these notes. Its diagonal entries are variances and its off-diagonal entries measure linear co-variation. Independence implies zero covariance when moments exist, but zero covariance does not generally imply independence. For example, a symmetric X and Y=X² can be dependent yet uncorrelated.

Σ̂ = (1/(n−1)) Σₖ (x⁽ᵏ⁾−x̄)(x⁽ᵏ⁾−x̄)ᵀ
R = Dσ⁻¹ Σ Dσ⁻¹, with Dσ=diag(σ₁,…,σd)

#### Centring removes the mean

PCA score formulas operate on deviations from the mean.

**Exam task:** Centre before covariance and restore the mean after reconstruction.

**Exact questions:** [AI-generated G26](index.html#question/generated/G26)

#### Sample covariance convention

The supplied notes use denominator n−1 for sample covariance.

**Exam task:** State the convention rather than silently switching to n.

**Exact questions:** [AI-generated G30](index.html#question/generated/G30)

#### Covariance versus correlation

Standardisation changes relative feature scaling and can change PCA directions.

**Exam task:** Justify scaling choices in a heterogeneous dataset.

**Exact questions:** [AI-generated G27](index.html#question/generated/G27), [AI-generated G30](index.html#question/generated/G30)

#### Decorrelation versus independence

Off-diagonal zero covariance does not rule out nonlinear dependence.

**Exam task:** Explain why PCA and ICA solve different representation problems.

**Exact questions:** [AI-generated G32](index.html#question/generated/G32), [AI-generated G36](index.html#question/generated/G36)

Source: 2026_SEMTM0051_Con01_PCA.pdf, physical PDF page 10

### Loadings, scores and dimension reduction

Sort covariance eigenvalues from largest to smallest. Put the corresponding unit eigenvectors in the columns of P: these are loading vectors. For a centred column x, the scores are Pᵀx. Keeping the first m components preserves the greatest variance among m-dimensional linear orthogonal projections and minimises squared reconstruction error. Reconstruct by multiplying by Pm and adding the original mean. PCA scores are uncorrelated; they are not generally independent.

y = Pᵀ(x−μ)
x̂ = μ + Pm Pmᵀ(x−μ)
Explained-variance ratio for component i = λᵢ / Σⱼ λⱼ
For Σ=[[2,1],[1,2]], component 1 explains 3/4=75%

#### Loadings versus scores

Loadings are directions; scores are coordinates of data in those directions.

**Exam task:** Use Pᵀ(x−μ) for columns or XcentredP for row observations.

**Exact questions:** [AI-generated G26](index.html#question/generated/G26), [AI-generated G29](index.html#question/generated/G29)

#### Retained variance ratio

A component explains λᵢ divided by the sum of eigenvalues.

**Exam task:** Sort eigenvalues and calculate the retained fraction.

**Exact questions:** [AI-generated G25](index.html#question/generated/G25), [AI-generated G29](index.html#question/generated/G29)

#### Low-rank reconstruction

Reconstruct the retained projection with Pm and add μ.

**Exam task:** Compute both the reconstructed point and its residual.

**Exact questions:** [AI-generated G26](index.html#question/generated/G26), [AI-generated G29](index.html#question/generated/G29)

#### Projection error interpretation

A pointwise squared error differs from an aggregate explained-variance ratio.

**Exam task:** Keep these two quantities separate in a numerical answer.

**Exact questions:** [AI-generated G29](index.html#question/generated/G29)

Source: 2026_SEMTM0051_Con01_PCA.pdf, physical PDF page 11

### Interpret the teacher’s examples

The ear-size example varies mostly along x=y (overall size), with smaller variation along x=−y (asymmetry). PCA discovers axes; a person must interpret what they mean. The election example treats 43 constituencies as observations and 11 vote-share categories as features, using correlation PCA. A few dominant components summarise much of the variation. Constant-sum vote shares impose a linear constraint, so the centred data cannot have full rank. Political labels for axes are interpretations of this dataset rather than guarantees of the method.

#### Interpretation requires context

PCA discovers mathematical directions; an analyst supplies semantic labels.

**Exam task:** Explain the ear-size size/asymmetry example.

**Exact questions:** [AI-generated G30](index.html#question/generated/G30)

#### Constant-sum feature constraint

Eleven vote shares summing to one produce a centred feature dependence.

**Exam task:** State a maximum feature rank of ten.

**Exact questions:** [AI-generated G30](index.html#question/generated/G30)

#### Sign and repeated-eigenvalue ambiguity

Flipped eigenvectors or different bases in a tied eigenspace preserve the represented subspace.

**Exam task:** Explain differing-looking valid PCA outputs.

**Exact questions:** [AI-generated G28](index.html#question/generated/G28)

#### Variance is not predictive importance

A direction with high unsupervised variance need not best predict labels.

**Exam task:** State what PCA optimises and what it does not guarantee.

**Exact questions:** [AI-generated G30](index.html#question/generated/G30)

Source: 2026_SEMTM0051_Con01_PCA.pdf, physical PDF page 13
## Independent component analysis

### Why this topic is introduced

PCA removes linear correlation, but uncorrelated coordinates can still be dependent. If observations are mixtures of independent processes, variance alone does not recover the sources. ICA adds independence and non-Gaussian structure to the representation objective.

### Connections

- Principal component analysis → contrasts → Independent component analysis: PCA decorrelates with second-order information; ICA seeks stronger independence using non-Gaussian structure.
- Independent component analysis → compares → Autoencoders & latent models: Independent coordinates and sparse dictionary features are different objectives for disentangling representations.
- Independent component analysis → interprets → Tokens & word representations: ICA on static embeddings probes semantic directions; their interpretation must be checked empirically.

### The cocktail-party model

Assume independent latent sources X are mixed linearly into observations Y=MX. Seek an unmixing W so Z=WY recovers independent coordinates. In the ideal invertible noiseless model W=M⁻¹. PCA looks for orthogonal axes of variance and decorrelates; ICA targets statistical independence and can identify sources whose mixing directions are not orthogonal. The recipe analogy distinguishes a garlic-dominated cuisine from one in which garlic and ginger vary together.

Y = MX; Z = WY = WMX
If W=M⁻¹, Z=X
Sources can only be recovered up to scale/sign and permutation without extra conventions.

#### Linear source mixing

Observed coordinates are weighted sums y=Ms of latent source coordinates.

**Exam task:** Write the mixing and unmixing equations with compatible shapes.

**Exact questions:** [AI-generated G31](index.html#question/generated/G31), [AI-generated G35](index.html#question/generated/G35)

#### Known inverse illustration

If M is known and invertible, W=M⁻¹ recovers the sources in the noiseless model.

**Exam task:** Solve a two-equation mixture and identify the assumption.

**Exact questions:** [AI-generated G31](index.html#question/generated/G31)

#### Why PCA is insufficient

Decorrelated coordinates can remain statistically dependent.

**Exam task:** Explain the need for information beyond covariance.

**Exact questions:** [AI-generated G32](index.html#question/generated/G32)

#### Recovery ambiguities

Independence does not set source order, scale or sign.

**Exam task:** State the ambiguities instead of claiming a unique numerical source identity.

**Exact questions:** [AI-generated G35](index.html#question/generated/G35)

Source: 2026_SEMTM0051_Con02_ICA.pdf, physical PDF page 1

### Why search for non-Gaussian directions?

The central-limit intuition is that mixtures of independent random contributions tend to look more Gaussian than individual non-Gaussian sources. FastICA searches for projections with strong non-Gaussianity; practical implementations commonly centre and whiten first, then optimise directions. Infomax is an alternative information-theoretic approach. General linear ICA needs suitable independent, non-Gaussian sources; multiple Gaussian sources cannot be uniquely separated by independence alone. Non-Gaussianity is a useful criterion under model assumptions, not a promise for arbitrary data.

A typical pipeline: centre → whiten → optimise non-Gaussian projections → check recovered components

#### Central-limit intuition

Mixtures tend to be more Gaussian than individual non-Gaussian sources under appropriate conditions.

**Exam task:** Explain the intuition without asserting it for every arbitrary distribution.

**Exact questions:** [AI-generated G35](index.html#question/generated/G35)

#### Non-Gaussian projection search

FastICA seeks useful non-Gaussian directions after preprocessing.

**Exam task:** Describe centre → whiten → optimise rather than treating PCA as the final answer.

**Exact questions:** [AI-generated G35](index.html#question/generated/G35)

#### Gaussian source non-identifiability

A whitened multivariate Gaussian does not select a unique source orientation.

**Exam task:** Explain the standard at-most-one-Gaussian-source condition.

**Exact questions:** [AI-generated G33](index.html#question/generated/G33)

#### Assumptions and diagnostics

Noise, noninvertible mixing and dependent sources can undermine a simple ICA model.

**Exam task:** Check model adequacy and recovered dependence empirically.

**Exact questions:** [AI-generated G35](index.html#question/generated/G35)

Source: 2026_SEMTM0051_Con02_ICA.pdf, physical PDF page 2

### The GloVe representation example

The notes apply 100-component ICA to 100-dimensional GloVe vectors for roughly 20,000 common words, excluding the very most frequent words. Inspect words with large coordinate values to interpret a component. Examples include cooking (teaspoon, sauce, garlic), music (albums, guitar, jazz), stock markets (FTSE, Nikkei, Nasdaq), computing (desktop, software, server), and injuries (knee, tendon, fracture). Some directions capture grammar or style, and some are unhelpful. Compare coherent lists with the mixed lists from PCA.

Interpretation workflow: rank examples by feature activation → propose a shared property → check new examples and interventions

#### A word vector becomes an observation

Each embedding is a data point whose coordinates can be transformed.

**Exam task:** Describe applying ICA to the supplied GloVe representation example.

**Exact questions:** [AI-generated G34](index.html#question/generated/G34)

#### Interpret top activations

Rank words along a component to propose a shared semantic or stylistic property.

**Exam task:** Give a plausible interpretation of music-related high-scoring words.

**Exact questions:** [AI-generated G34](index.html#question/generated/G34)

#### Validate rather than cherry-pick

A coherent list is evidence for a hypothesis, not a universal or causal proof.

**Exam task:** Check held-out examples and controls.

**Exact questions:** [AI-generated G34](index.html#question/generated/G34), [AI-generated G66](index.html#question/generated/G66)

#### Compare representation objectives

PCA, ICA and sparse AEs optimise different notions of useful coordinates.

**Exam task:** Compare variance, independence and sparse reconstruction.

**Exact questions:** [AI-generated G36](index.html#question/generated/G36)

Source: 2026_SEMTM0051_Con02_ICA.pdf, physical PDF page 4
## Autoencoders & latent models

### Why this topic is introduced

A single linear PCA subspace may not describe a curved data manifold. An autoencoder learns a more flexible reconstruction code. Ordinary codes need not support prior sampling, motivating VAE regularisation; a wide dictionary needs selective use, motivating sparse autoencoders.

### Connections

- Principal component analysis → motivates → Autoencoders & latent models: A linear reconstruction subspace suggests learning a nonlinear encoder and decoder.
- Independent component analysis → compares → Autoencoders & latent models: Independent coordinates and sparse dictionary features are different objectives for disentangling representations.
- Neural networks → implements → Autoencoders & latent models: Encoder and decoder are neural feature maps trained by reconstruction-based losses.
- Backpropagation → trains → Autoencoders & latent models: Reconstruction gradients train encoders; VAE reparameterisation restores a pathwise gradient through sampled latents.
- Autoencoders & latent models → connects → Generative vision models: VAEs generate by prior sampling; latent diffusion uses a learned compressed representation.

### Autoencoders and learned representations

A basic autoencoder maps an input to a code and reconstructs the input from that code. A bottleneck encourages a compressed representation useful for feature learning, denoising or compression. A denoising autoencoder reconstructs a clean target from a corrupted input. A linear bottleneck autoencoder with squared error is closely related to a PCA subspace; nonlinear encoders and decoders extend the representation beyond a single linear subspace. Merely copying the input through a wide unregularised network need not learn useful structure.

h = encoder(x); x̂ = decoder(h)
Reconstruction loss = ‖x−x̂‖²

#### Reconstruction learning

An encoder and decoder learn to reproduce the input through an intermediate representation.

**Exam task:** Define an AE and identify the learning target.

**Exact questions:** [Sample A15](index.html#question/sample/a15)

#### Bottleneck and useful codes

A bottleneck constrains copying and encourages compression.

**Exam task:** Explain denoising, compression and downstream feature uses.

**Exact questions:** [Sample A15](index.html#question/sample/a15), [AI-generated G60](index.html#question/generated/G60)

#### Linear PCA connection

Linear reconstruction with a suitable bottleneck relates to a principal subspace.

**Exam task:** State the relationship without claiming every AE learns exactly the PCA coordinates.

**Exact questions:** [AI-generated G36](index.html#question/generated/G36)

#### Nonlinear generalisation

Flexible encoder/decoder compositions can represent structure beyond one linear subspace.

**Exam task:** Explain why nonlinear compression is introduced after linear PCA.

**Exact questions:** [AI-generated G36](index.html#question/generated/G36)

Source: 2026_sample_semtm0051_ans.pdf, physical PDF page 4

### The variational autoencoder objective

A VAE encoder qϕ(z|x) describes a distribution, commonly a Gaussian whose mean and variance depend on x. A latent sample passes to a probabilistic decoder pθ(x|z). Maximise the evidence lower bound (ELBO): the expected reconstruction log-likelihood rewards reconstructing x, while KL penalises a posterior far from the prior. Without the KL regulariser, the latent distributions need not align with the sampling prior and prior samples can land in gaps. Generate new data by sampling z from p(z), commonly N(0,I), then decoding it.

ln pθ(x) ≥ E_q[ln pθ(x|z)] − KL(qϕ(z|x) ‖ p(z))
KL(N(μ,σ²) ‖ N(0,1)) = ½(μ²+σ²−1−ln σ²)
μ=1, σ=2 ⇒ KL≈1.30685; KL=0 at μ=0, σ=1

#### Distribution instead of a single code

The encoder predicts a latent distribution, commonly via μ and variance.

**Exam task:** Contrast an AE code with VAE sampling.

**Exact questions:** [Sample A16](index.html#question/sample/a16)

#### ELBO rewards and penalties

Expected reconstruction log-likelihood is rewarded; KL to the prior is subtracted.

**Exam task:** State maximise ELBO versus minimise negative ELBO.

**Exact questions:** [Sample B3](index.html#question/sample/b3), [AI-generated G41](index.html#question/generated/G41)

#### Gaussian KL calculation

Use 1/2(μ²+σ²−1−lnσ²) with σ as standard deviation.

**Exam task:** Convert an explicitly supplied variance before substitution.

**Exact questions:** [AI-generated G37](index.html#question/generated/G37), [AI-generated G41](index.html#question/generated/G41)

#### Sampling for new generation

Fresh generation samples p(z) and passes it through the decoder.

**Exam task:** Distinguish prior generation from encoder-conditioned reconstruction.

**Exact questions:** [Sample A17](index.html#question/sample/a17), [AI-generated G39](index.html#question/generated/G39)

Source: 2026_sample_semtm0051.pdf, physical PDF page 4

### Move the randomness outside the encoder parameters

A naive random draw does not expose an ordinary deterministic computational path from the reconstruction loss to μ and σ. Reparameterise as z=μ+σε with ε sampled independently from N(0,1). Conditional on that ε, z is differentiable in μ and σ, allowing a pathwise gradient estimator. This supports ordinary backpropagation through the deterministic transformation while keeping the sample random.

ε ~ N(0,1); z = μ+σε
∂z/∂μ=1;  ∂z/∂σ=ε

#### Naive sampling breaks an ordinary path

A random draw is not exposed as a deterministic differentiable function of encoder parameters.

**Exam task:** Explain the pathwise-gradient problem precisely.

**Exact questions:** [Sample B3](index.html#question/sample/b3)

#### Separate noise from parameters

Use z=μ+σε with ε drawn independently of encoder outputs.

**Exam task:** Compute a fixed-noise latent sample.

**Exact questions:** [AI-generated G38](index.html#question/generated/G38), [AI-generated G41](index.html#question/generated/G41)

#### Derivatives conditional on ε

For a fixed draw, ∂z/∂μ=1 and ∂z/∂σ=ε.

**Exam task:** Show how reconstruction gradients reach the encoder.

**Exact questions:** [AI-generated G38](index.html#question/generated/G38)

#### A stochastic estimator remains stochastic

Reparameterisation enables a gradient estimator without removing sampling randomness.

**Exam task:** Avoid calling it a deterministic generative model.

**Exact questions:** [Sample B3](index.html#question/sample/b3), [AI-generated G41](index.html#question/generated/G41)

Source: 2026_sample_semtm0051_ans.pdf, physical PDF page 8

### Sparse autoencoders and interpretable dictionaries

A sparse autoencoder can use a hidden dimension far larger than the input dimension. The L1 activation penalty encourages using only a small number of dictionary features for each input. Each hidden unit, equivalently a column of the decoder matrix in the supplied column-vector convention, represents a feature direction in the original activation space. To test interpretability, examine top-activating inputs for a shared pattern; an intervention can add or remove a feature direction and inspect resulting output changes.

h = ReLU(We x+b)
L = ‖x−Wd h‖² + λ‖h‖₁

#### Wide dictionary versus narrow code

A wide sparse AE offers many candidate features while limiting usage per input.

**Exam task:** Explain why a hidden dimension larger than input can still be useful.

**Exact questions:** [Sample A18](index.html#question/sample/a18), [AI-generated G40](index.html#question/generated/G40)

#### L1 activation penalty

The activation norm encourages a few or small active features.

**Exam task:** Explain the effect of increasing λ and the reconstruction trade-off.

**Exact questions:** [AI-generated G42](index.html#question/generated/G42)

#### Feature as a decoder direction

One hidden coordinate corresponds to a dictionary/decoder column in the supplied convention.

**Exam task:** Define what the feature is, not just its proposed topic name.

**Exact questions:** [Sample B3](index.html#question/sample/b3), [AI-generated G42](index.html#question/generated/G42)

#### Interpretability checks

Use high-activation inputs, held-out controls and interventions on feature directions.

**Exam task:** Describe a concrete check and avoid guaranteeing causal interpretability.

**Exact questions:** [Sample B3](index.html#question/sample/b3), [AI-generated G42](index.html#question/generated/G42)

Source: 2026_sample_semtm0051.pdf, physical PDF page 2
## Convolution & image geometry

### Why this topic is introduced

A fully connected image layer ignores locality and learns separate weights at every position. Images contain repeated local patterns. Shared spatial kernels exploit this structure while reducing parameters and building hierarchical receptive fields.

### Connections

- Neural networks → specialises → Convolution & image geometry: Local connectivity and spatial weight sharing constrain an otherwise general learned affine operation.
- Convolution & image geometry → builds → Vision architectures & detection: CNN operators compose into backbones and task heads with predictable shapes and costs.

### Locality and weight sharing

A convolutional layer applies the same small kernel at every spatial location. Local connectivity and shared weights reduce the number of trainable parameters relative to an unrestricted fully connected map over an image. Multiple input channels contribute to each output channel. The usual machine-learning implementation uses cross-correlation (no kernel flip), consistent with the supplied local weighted-sum formula. Pooling reduces spatial resolution and has no trainable kernel weights in ordinary max pooling.

Output size = floor((N+2P−K)/S)+1   (dilation 1)
Parameters = Cout(Cin K²+1)          (one bias/output channel)
64×64, K=3, S=1, P=1 ⇒ 64×64; 2×2 pool, S=2 ⇒ 32×32
Cin=8, Cout=32, K=5 ⇒ 32(8·25+1)=6432

#### Output-size floor formula

For dilation one: floor((N+2P−K)/S)+1.

**Exam task:** Apply the formula separately to every convolution and pooling stage.

**Exact questions:** [Sample A19](index.html#question/sample/a19), [AI-generated G43](index.html#question/generated/G43)

#### Channel-aware kernel count

A standard layer has Cout(CinK²+1) trainable parameters with biases.

**Exam task:** Count spatial kernel weights across all input and output channels.

**Exact questions:** [Sample A20](index.html#question/sample/a20), [AI-generated G44](index.html#question/generated/G44)

#### Locality and weight sharing

The same small kernel is used across positions instead of learning a full image-to-image matrix.

**Exam task:** Give both explanations for parameter efficiency.

**Exact questions:** [Sample A21](index.html#question/sample/a21), [AI-generated G48](index.html#question/generated/G48)

#### Pooling changes geometry, not kernel parameters

Ordinary max pooling selects maxima and normally has no trainable kernel weights.

**Exam task:** Track shape and distinguish activations from learned parameters.

**Exact questions:** [Sample A19](index.html#question/sample/a19), [AI-generated G47](index.html#question/generated/G47)

Source: 2026_sample_semtm0051.pdf, physical PDF page 3

### Efficient convolutions and receptive fields

A 1×1 convolution mixes channels independently at each spatial position; it can reduce channels before a more expensive spatial convolution. Depthwise convolution applies a spatial filter to each channel independently; pointwise convolution then mixes channels. Stacking small kernels increases receptive field and inserts additional nonlinearities. Group convolution separates channel groups; channel shuffling allows information exchange. Efficient architectures balance accuracy, parameter storage and computation.

Standard K×K weights: K² Cin Cout
Depthwise + pointwise weights: K² Cin + Cin Cout
Two stride-1 3×3 layers have an effective 5×5 receptive field

#### Pointwise channel mixing

A 1×1 convolution mixes channels at a spatial position.

**Exam task:** Explain channel bottlenecks without claiming it directly combines adjacent positions.

**Exact questions:** [AI-generated G46](index.html#question/generated/G46)

#### Depthwise plus pointwise weights

The comparable weight counts are K²CinCout versus K²Cin+CinCout.

**Exam task:** Omit or include biases consistently in the comparison.

**Exact questions:** [AI-generated G45](index.html#question/generated/G45)

#### Receptive-field growth

Stacked local operators allow an output to depend on a larger input region.

**Exam task:** Distinguish receptive-field size from feature-map dimensions.

**Exact questions:** [AI-generated G48](index.html#question/generated/G48)

#### Efficiency has multiple dimensions

Parameter storage, operation count, memory traffic and latency need not change proportionally.

**Exam task:** Avoid inferring actual device speed only from a weight count.

**Exact questions:** [AI-generated G48](index.html#question/generated/G48)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 15
## Vision architectures & detection

### Why this topic is introduced

Convolution gives a useful operation, not a complete solution to every image task. Deep backbones, patch attention, region proposals and dense decoders organise representations around classification, detection, segmentation, scale and computation constraints.

### Connections

- Convolution & image geometry → builds → Vision architectures & detection: CNN operators compose into backbones and task heads with predictable shapes and costs.
- Attention & Transformers → transfers → Vision architectures & detection: Image patches can be embedded as tokens and processed by global or windowed attention.
- Vision architectures & detection → extends → Generative vision models: Understanding image representations provides reusable encoders, decoders and features for synthesis.
- Training & optimisation → constrains → Vision architectures & detection: Architectures trade off parameter count, optimisation difficulty, generalisation and actual runtime.

### Compare CNN design decisions

Read architecture history as a sequence of design choices rather than a list of names. AlexNet popularised deep CNN image classification with ReLU, augmentation, dropout and GPU training. VGG stacks small kernels; Inception combines parallel multi-scale paths; ResNet adds residual updates; DenseNet concatenates earlier feature maps. Ensembles such as Trimps-Soushen combine models, while compact models target constrained devices. Top-1 and top-5 error measure whether the true label is absent from the first one or five predictions.

#### Depth and multi-scale branches

VGG stacks small kernels; Inception combines differently sized processing paths.

**Exam task:** Explain the mechanism rather than listing model names.

**Exact questions:** [AI-generated G54](index.html#question/generated/G54)

#### Residual addition versus concatenation

ResNet adds a residual update; DenseNet concatenates earlier maps.

**Exam task:** State the distinct reuse operations accurately.

**Exact questions:** [AI-generated G49](index.html#question/generated/G49)

#### Compact channel operations

MobileNet, ShuffleNet and SENet use different efficient or adaptive channel mechanisms.

**Exam task:** Compare separable filtering, shuffling and channel gating.

**Exact questions:** [AI-generated G48](index.html#question/generated/G48), [AI-generated G54](index.html#question/generated/G54)

#### Architecture scaling trade-offs

EfficientNet balances width, depth and resolution; NAS searches a specified space and objective.

**Exam task:** Explain why model size alone is not a complete architecture criterion.

**Exact questions:** [AI-generated G54](index.html#question/generated/G54)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 8

### Patch tokens, local windows and self-supervision

ViT splits an image into patches, linearly embeds each patch, adds position information and a class token, then uses a Transformer encoder. DeiT adds data-efficient training and distillation. Swin uses hierarchical window attention and shifts windows between layers to exchange information. ConViT introduces a soft convolutional inductive bias that attention can move away from. ConvNeXt modernises CNN design and training. A masked autoencoder (MAE) reconstructs missing image patches as a self-supervised objective.

#### ViT patch representation

Flattened image patches are embedded into tokens with position information.

**Exam task:** Describe the image-to-sequence conversion and class-token use.

**Exact questions:** [AI-generated G51](index.html#question/generated/G51)

#### Local windows and shifted windows

Swin constrains attention locally and shifts partitions to connect previous windows.

**Exam task:** Explain cross-window information flow.

**Exact questions:** [AI-generated G52](index.html#question/generated/G52)

#### Distillation and inductive biases

DeiT uses distillation; ConViT introduces soft convolutional bias; ConvNeXt modernises CNN design.

**Exam task:** Compare the design decisions, not just their dates.

**Exact questions:** [AI-generated G54](index.html#question/generated/G54)

#### Masked image self-supervision

MAE hides patches and reconstructs missing image content.

**Exam task:** Identify where targets come from and how this differs from labelled recognition.

**Exact questions:** [AI-generated G60](index.html#question/generated/G60)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 20

### From boxes to masks

Classification gives image labels. Object detection predicts classes and bounding boxes; instance segmentation adds a mask for each instance. Earlier pipelines used sliding windows and hand-designed Haar or HOG features with shallow classifiers. Non-maximum suppression removes redundant overlapping detections. R-CNN extracts features for proposed regions; Fast R-CNN shares a convolutional map and pools regions; Faster R-CNN learns region proposals with an RPN. Single-shot methods such as SSD and YOLO predict detections directly in one pipeline. U-Net combines a contracting encoder and expanding decoder with skip connections for dense segmentation.

#### Classification, boxes and masks

Recognition tasks require different outputs: image labels, boxes, pixel categories or object instances.

**Exam task:** Distinguish semantic from instance segmentation.

**Exact questions:** [AI-generated G53](index.html#question/generated/G53)

#### Region proposal evolution

R-CNN repeats region feature extraction; Fast R-CNN shares maps; Faster R-CNN learns proposals.

**Exam task:** Identify the RPN and its relationship to shared features.

**Exact questions:** [AI-generated G50](index.html#question/generated/G50), [AI-generated G53](index.html#question/generated/G53)

#### Single-stage versus region-based detection

SSD and YOLO predict detections directly in a single-stage pipeline.

**Exam task:** Contrast proposal mechanisms and outputs without assuming one method always wins.

**Exact questions:** [AI-generated G53](index.html#question/generated/G53)

#### Dense decoders and overlap handling

U-Net produces dense predictions; NMS removes redundant overlapping boxes; Mask R-CNN adds instance masks.

**Exam task:** Match each mechanism to the actual output problem.

**Exact questions:** [AI-generated G53](index.html#question/generated/G53)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 26
## Generative vision models

### Why this topic is introduced

Recognition predicts a label or description of observed data. Generation asks how to produce new data, requiring a distribution and a sampling mechanism. The slides compare adversarial, latent-variable, autoregressive, invertible and denoising routes to that goal.

### Connections

- Autoencoders & latent models → connects → Generative vision models: VAEs generate by prior sampling; latent diffusion uses a learned compressed representation.
- Generative vision models → shares → Attention & Transformers: Autoregressive image and language models both prevent future-information leakage.
- Vision architectures & detection → extends → Generative vision models: Understanding image representations provides reusable encoders, decoders and features for synthesis.

### Compare the modelling mechanisms

A discriminative model learns a conditional decision rule such as p(y|x); a generative model represents a data distribution and can produce samples. Conditional generation can model p(x|y), while other models target p(x) or p(x,y). The vision slides survey several distinct mechanisms. Compare each by how it trains and how it generates, rather than assuming every method has an encoder or an explicit likelihood.

#### A distribution and a sampling story

Generative modelling must specify what is modelled and how a sample is obtained.

**Exam task:** Compare VAE prior decoding with GAN noise-to-sample generation.

**Exact questions:** [AI-generated G57](index.html#question/generated/G57), [AI-generated G59](index.html#question/generated/G59)

#### Autoregressive factorisation

A joint distribution is a product of conditionals on earlier variables.

**Exam task:** Write the factorisation and sampling order.

**Exact questions:** [AI-generated G55](index.html#question/generated/G55)

#### Flows and invertibility

Exact change-of-variables likelihood uses an invertible map and a Jacobian correction.

**Exam task:** Explain why a general lossy bottleneck does not meet this condition.

**Exact questions:** [AI-generated G56](index.html#question/generated/G56)

#### Diffusion and latent diffusion

A learned reverse denoising process can operate in pixels or a compressed latent space.

**Exam task:** Explain the latent-space efficiency idea and decoder’s role.

**Exact questions:** [AI-generated G58](index.html#question/generated/G58), [AI-generated G59](index.html#question/generated/G59)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 37

### Connect vision generation to the sample paper

VAEs share the representation-learning theme with PCA and autoencoders. Autoregressive image models share the no-future-information principle with causal language models. Flows require invertibility and dimension-preserving transforms, unlike a general lossy autoencoder. GAN and diffusion sampling do not use the VAE ELBO as their defining training objective. A model family’s name alone is not a worked explanation: describe the distribution, training signal and sampling steps.

#### Compression to latent generation

AE representations become a component of VAE or latent-diffusion pipelines.

**Exam task:** Separate representation learning from a complete sampling model.

**Exact questions:** [AI-generated G39](index.html#question/generated/G39), [AI-generated G58](index.html#question/generated/G58)

#### Causal masking across modalities

Pixel autoregression and next-token language modelling share a no-future-information constraint.

**Exam task:** Explain why seeing a target-dependent future input would leak information.

**Exact questions:** [AI-generated G55](index.html#question/generated/G55), [AI-generated G69](index.html#question/generated/G69)

#### Training-objective differences

Adversarial training, ELBO optimisation, exact flow likelihood and denoising objectives differ.

**Exam task:** Compare mechanisms without assigning the VAE loss to every generator.

**Exact questions:** [AI-generated G59](index.html#question/generated/G59)

#### Denoising is not automatically diffusion

A robust denoising AE and a full probabilistic reverse diffusion chain are distinct constructions.

**Exam task:** Identify targets, corruption and the complete generation process.

**Exact questions:** [AI-generated G60](index.html#question/generated/G60)

Source: SEMTM0051.Week10.LVMs.pdf, physical PDF page 39
## Tokens & word representations

### Why this topic is introduced

Text is discrete and a one-hot word ID has no learned semantic geometry. Tokenisation makes usable units; embedding methods learn from context. Static word vectors still cannot resolve every context-dependent meaning, preparing the need for contextual sequence models.

### Connections

- Tokens & word representations → provides → Attention & Transformers: Token embeddings become the sequence representations projected into queries, keys and values.
- Independent component analysis → interprets → Tokens & word representations: ICA on static embeddings probes semantic directions; their interpretation must be checked empirically.

### BPE training and inference

A tokenizer converts raw text into tokens and numerical IDs. Subword tokenisation balances reusable pieces with vocabulary size. BPE training begins from small units, repeatedly counts adjacent pairs and merges a selected frequent pair, extending the vocabulary. Inference applies the learned merge rules in their learned priority order; it does not retrain on the new sentence. WordPiece and Unigram are other subword approaches named in the slides.

Toy word: hugs → hug + s (depending on learned merges)
Text → token IDs → embedding lookup → sequence of vectors

#### Discrete units before dense vectors

A tokenizer maps text to units and IDs; an embedding table maps IDs to vectors.

**Exam task:** Do not treat a token as necessarily a complete word.

**Exact questions:** [AI-generated G62](index.html#question/generated/G62)

#### Count BPE pair frequencies

Training repeatedly selects adjacent frequent pairs under stated boundaries and tie-breaking rules.

**Exam task:** Count occurrences with corpus word frequencies.

**Exact questions:** [AI-generated G61](index.html#question/generated/G61), [AI-generated G65](index.html#question/generated/G65)

#### Apply learned merge priorities

Inference starts from small units and applies stored merge rules.

**Exam task:** Work through the trained rules without retraining on a test word.

**Exact questions:** [AI-generated G65](index.html#question/generated/G65)

#### Vocabulary depends on conventions

Boundary markers, pretokenisation and tie breaks affect a toy BPE result.

**Exam task:** State the conventions supplied by the question.

**Exact questions:** [AI-generated G61](index.html#question/generated/G61), [AI-generated G65](index.html#question/generated/G65)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 6

### Why dense representations replace one-hot geometry

A one-hot vector has one nonzero entry and dimension equal to vocabulary size. Distinct one-hot vectors are orthogonal, providing no learned notion of similarity. An embedding lookup selects a dense trainable row of an embedding matrix. Distributional learning uses the contexts in which a word occurs. A co-occurrence matrix counts nearby words; SVD gives compact representations but can be expensive for very large vocabularies, sparse counts and changing data.

Vocabulary size V, embedding width d ⇒ embedding table V×d
One-hot row eᵢ times E selects row Eᵢ
Similarity can be assessed with cosine(u,v)=u·v/(‖u‖‖v‖)

#### One-hot geometry limitation

Distinct one-hot IDs are orthogonal and do not encode learned semantic similarity.

**Exam task:** Explain what is missing beyond word identity.

**Exact questions:** [AI-generated G66](index.html#question/generated/G66)

#### Embedding table lookup

A V×d table has one d-dimensional row per vocabulary item.

**Exam task:** Show that multiplying a one-hot row selects its matching row.

**Exact questions:** [AI-generated G62](index.html#question/generated/G62)

#### Distributional context and co-occurrence

Context counts can provide semantic evidence and be factorised into compact representations.

**Exam task:** Explain sparsity, scale and updating limits of very large count matrices.

**Exact questions:** [AI-generated G66](index.html#question/generated/G66)

#### Similarity needs interpretation

Dense-vector cosine similarity probes learned geometry but is not a universal semantic guarantee.

**Exam task:** Interpret analogies or clusters with appropriate empirical checks.

**Exact questions:** [AI-generated G66](index.html#question/generated/G66), [AI-generated G34](index.html#question/generated/G34)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 10

### Skip-gram, CBOW and efficient objectives

Skip-gram predicts context words from a centre word. CBOW predicts a centre word from a bag of context words. Skip-gram maximises conditional context probabilities, commonly using a softmax of input/output embedding dot products. Its context-factorisation assumption treats context words as conditionally independent given the centre. Negative sampling updates a positive pair and selected negative words rather than evaluating a complete vocabulary softmax; hierarchical softmax is another efficiency strategy. These are distinct objectives or parameterisations, not identical calculations.

p(o|c)=exp(uₒᵀv𝒸) / Σ_w exp(u_wᵀv𝒸)
J = − average over centre/context pairs of ln p(o|c)

#### Skip-gram direction

The centre word is used to predict context words.

**Exam task:** State the conditional prediction direction.

**Exact questions:** [AI-generated G63](index.html#question/generated/G63)

#### CBOW direction

A bag of nearby context words predicts the centre word.

**Exam task:** Contrast it with skip-gram and note bag-of-context order limitations.

**Exact questions:** [AI-generated G63](index.html#question/generated/G63)

#### Efficient training objectives

Negative sampling updates selected positive/negative words; hierarchical softmax is another strategy.

**Exam task:** Explain the computational saving without claiming identical full-softmax evaluation.

**Exact questions:** [AI-generated G64](index.html#question/generated/G64)

#### Static versus contextual vectors

A static word vector is reused across contexts; a Transformer representation depends on its sequence.

**Exam task:** Explain the limitation that motivates contextual attention.

**Exact questions:** [AI-generated G66](index.html#question/generated/G66), [AI-generated G72](index.html#question/generated/G72)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 14
## Attention & Transformers

### Why this topic is introduced

A fixed word representation cannot decide which earlier words matter for the current prediction. Attention makes retrieval depend on the input itself. Queries and keys select context, values carry information, and causal masks align training with generation.

### Connections

- Attention & Transformers → transfers → Vision architectures & detection: Image patches can be embedded as tokens and processed by global or windowed attention.
- Generative vision models → shares → Attention & Transformers: Autoregressive image and language models both prevent future-information leakage.
- Tokens & word representations → provides → Attention & Transformers: Token embeddings become the sequence representations projected into queries, keys and values.
- Regression & probability → normalises → Attention & Transformers: Row-wise softmax turns query–key scores into a probability-weighted mixture of values.
- Backpropagation → trains → Attention & Transformers: Attention is a differentiable composition whose parameters can be learned from token losses.

### Attention is content-based retrieval

A query expresses what a token seeks. A key advertises what another token can match. A value is the content retrieved and combined. Project representations to Q,K,V, calculate query–key dot products, scale by √dₖ, apply any mask, then softmax each row and multiply by V. Self-attention takes queries, keys and values from the same sequence; cross-attention uses queries from one sequence and keys/values from another.

Attention(Q,K,V)=softmax(QKᵀ/√dₖ + mask)V
Q: n_q×dₖ; K: n_k×dₖ; V: n_k×dᵥ
Scores: n_q×n_k; output: n_q×dᵥ

#### Query, key and value roles

Queries seek, keys match, and values contain retrieved information.

**Exam task:** Give all three roles with an explicit lookup analogy.

**Exact questions:** [Sample A22](index.html#question/sample/a22), [AI-generated G72](index.html#question/generated/G72)

#### Score matrix shapes

QKᵀ has one row per query and one column per key.

**Exam task:** Track nq×dk, nk×dk and nk×dv through the operation.

**Exact questions:** [AI-generated G71](index.html#question/generated/G71)

#### Row-wise weighted retrieval

Apply softmax over keys for each query, then multiply the weights by V.

**Exam task:** Compute weights and a weighted value vector, not a weighted key vector.

**Exact questions:** [AI-generated G67](index.html#question/generated/G67), [AI-generated G71](index.html#question/generated/G71)

#### Self versus cross-attention

Q,K,V share a sequence in self-attention; cross-attention separates query and memory sequences.

**Exam task:** State the origin of the matrices in each setting.

**Exact questions:** [Sample A23](index.html#question/sample/a23), [AI-generated G72](index.html#question/generated/G72)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 26

### Causal masking and the sample calculation

A causal mask removes scores with j>i, commonly by setting them to −∞ before softmax, giving exactly zero attention weight. This prevents future-token leakage during next-token training. For the supplied embeddings (1,1),(1,0),(0,1) with all projections I and scaling explicitly ignored, the raw score matrix has rows (2,1,1),(1,1,0),(1,0,1). Position 1 outputs (1,1); position 2 uses equal weights ½,½ and outputs (1,½).

S=[[2,1,1],[1,1,0],[1,0,1]]
Causal S=[[2,−∞,−∞],[1,1,−∞],[1,0,1]]
o₁=(1,1); o₂=(1,0.5)
Score count=n²; doubling n gives four times as many scores

#### Mask before normalisation

Future scores j>i are removed before softmax, usually with −∞.

**Exam task:** Identify the upper-triangular excluded entries.

**Exact questions:** [Sample A24](index.html#question/sample/a24), [Sample B2](index.html#question/sample/b2)

#### A zero score still has positive mass

exp(0)=1, so setting a forbidden score to zero does not exclude it.

**Exam task:** Explain why the zero-score shortcut leaks future information.

**Exact questions:** [AI-generated G69](index.html#question/generated/G69)

#### Sample-specific scaling convention

The supplied long question omits 1/√d even though the general formula uses it.

**Exam task:** Follow the stated convention in the exact numerical calculation.

**Exact questions:** [Sample B2](index.html#question/sample/b2), [AI-generated G71](index.html#question/generated/G71)

#### Quadratic dense score count

Every query–key pair contributes a score when using dense self-attention.

**Exam task:** Compute n² counts and context-length scaling factors.

**Exact questions:** [Sample B2](index.html#question/sample/b2), [AI-generated G68](index.html#question/generated/G68)

Source: 2026_sample_semtm0051.pdf, physical PDF page 4

### Heads, positions and residual connections

Multi-head attention learns separate query/key/value projections, allowing different positions or representation subspaces to be used at the same time; head outputs are concatenated and projected. Position information distinguishes token order, since content-only attention cannot infer absolute order. The original Transformer uses sinusoidal positional encodings; learned position embeddings are another choice. Residual connections provide an additive path around a sublayer, with normalisation and position-wise feedforward transformations composing the block. Earlier encoder–decoder temporal attention used context vectors from encoder states; teacher forcing supplies previous ground-truth tokens during training.

headᵢ=Attention(QWᵢQ, KWᵢK, VWᵢV)
MultiHead=Concat(head₁,…,headₕ)WO
Residual form: x + Sublayer(x)

#### Multiple learned heads

Different projections provide separate learned subspaces or attention patterns.

**Exam task:** Explain why more heads are useful rather than merely duplicating one fixed pattern.

**Exact questions:** [Sample A25](index.html#question/sample/a25), [AI-generated G72](index.html#question/generated/G72)

#### Position information

Content-only attention does not identify absolute ordering by itself.

**Exam task:** Explain why positional encodings or embeddings are supplied.

**Exact questions:** [AI-generated G72](index.html#question/generated/G72)

#### Residual and feedforward components

Attention sublayers are composed with residual paths, normalisation and position-wise transformations.

**Exam task:** Describe the block’s information flow and distinguish residual addition from concatenation.

**Exact questions:** [AI-generated G49](index.html#question/generated/G49), [AI-generated G72](index.html#question/generated/G72)

#### Encoder–decoder temporal context

Earlier attention retrieves encoder-state context during decoding; teacher forcing supplies prior true tokens in training.

**Exam task:** Distinguish training information from autoregressive inference.

**Exact questions:** [AI-generated G72](index.html#question/generated/G72)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 24

### GPT, BERT and T5: architecture follows the objective

A causal decoder-only model such as the GPT family predicts the next token and generates autoregressively. An encoder-only BERT-style model predicts masked tokens using bidirectional context; original BERT also uses next-sentence prediction with [CLS] and [SEP]. An encoder–decoder model such as T5 frames tasks as text-to-text: the encoder reads the input, and the decoder generates the output with causal self-attention plus cross-attention to the encoder. Training and inference expose different available outputs; causal masking preserves the generation constraint during parallel training.

Causal LM: p(x₁,…,xₙ)=∏ₜ p(xₜ | x₍<t₎)
Next-token CE: −Σₜ ln p(xₜ | x₍<t₎)

#### Causal decoder language modelling

A decoder-only model predicts next tokens from earlier context.

**Exam task:** Write the autoregressive likelihood and explain masking.

**Exact questions:** [AI-generated G70](index.html#question/generated/G70), [AI-generated G55](index.html#question/generated/G55)

#### Bidirectional masked modelling

An encoder-only masked LM uses visible surrounding context to recover hidden tokens.

**Exam task:** Compare the objective with causal next-token prediction.

**Exact questions:** [AI-generated G70](index.html#question/generated/G70)

#### Text-to-text encoder–decoder

The input encoder and causal output decoder are linked by cross-attention.

**Exam task:** Identify which side is bidirectional and which side generates causally.

**Exact questions:** [AI-generated G70](index.html#question/generated/G70), [AI-generated G72](index.html#question/generated/G72)

#### Original BERT auxiliary task

The supplied slides also discuss next-sentence prediction with [CLS] and [SEP].

**Exam task:** Describe its classification purpose without assuming all masked LMs use that auxiliary task.

**Exact questions:** [AI-generated G70](index.html#question/generated/G70)

Source: SEMTM0051.Week11.LLMs.pdf, physical PDF page 30

## Exam execution

### Section A · 25 × 2 = 50

Attempt all short questions. Give a precise definition or formula, then the requested result. Method and units/shapes can earn separate credit.

### Section B · best 2 × 10 = 20

Three long questions are supplied: backpropagation, causal attention and probabilistic/sparse autoencoders. Practise all three; the highest two marks count.

### Calculate in a fixed order

State the convention → write the formula → substitute → retain precision → show intermediate values → round the final answer.

### Protect the easy marks

Check bias counts, row/column shapes, log versus probability, standard deviation versus variance, the ReLU gate, and mask-before-softmax order.

### Use a retrieval loop

Read one section → attempt its exercise closed-book → self-mark → explain the error → retry with changed numbers. Review completion is self-reported.

### Know the scope of this map

This connects all 12 topic areas in the 10 recovered PDFs. Six of the 16 referenced attachments remain unavailable. Forecast questions are AI-generated, not official predictions.

