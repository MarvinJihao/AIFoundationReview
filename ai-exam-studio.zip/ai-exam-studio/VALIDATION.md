# Validation record — v4

Updated 7 November 2026. Scope remains the 10 recovered PDFs (195 pages); six referenced files are unavailable.

## New formula-sheet and study-timer checks

**8 study-tool groups passed**, in addition to the prior 34 groups rerun against the current application: **42 local application groups total**. Run `node tests/validate-tools.cjs`.

Checks cover the 11 formula sections and key source conventions; custom-duration bounds; deadline-based elapsed time; exact pause/resume behaviour; expiry after serialisation/reload; reset/restart; old-backup compatibility and malformed timer rejection; and app integration through the persistent drawer and settings controls.

The drawer and timer browser layout and end-to-end clicks have not been verified in a real browser in this environment. The prior browser restriction still applies.

## Separate cloud implementation

A cloud source package has been prepared with authenticated per-user storage, optimistic revision checking, automatic merging of independent edits, explicit conflict choices with safety backups, and synchronisation of study-timer state. Twelve cloud checks and a real in-memory SQLite migration/CAS check passed. These use mocked D1 request plumbing and actual SQLite SQL validation; they do not establish that production sync is live.

**Deployment is not complete.** A private Sites project was created, but the source upload failed with a name-resolution/runtime error. The required elevated execution was rejected because the current approval policy disallows it. No production deployment or two-device live-sync test succeeded.

## Retained v3 checks


**10 v3 validation groups passed**, in addition to the 15 arithmetic/source groups and 9 v2 groups rerun on the current files: **34 groups total**. Run `node tests/validate-v3.cjs`.

- All 160 points cover the 40 sections, with an explicit knowledge statement, exam task and resolvable question reference.
- Every exact-question link resolves. All 159 question pages render with the correct supplied/generated origin and reverse learning links.
- All 22 topic relationships resolve and explain their meaning; the clickable relationship SVG has 12 topic links and 22 edges.
- Topic/section/point deep links expose the selected explanation, topic motivation, exam task and exact questions.
- The three map levels have bounded, non-overlapping branch layouts.
- SVG and detailed-outline exports retain all 160 points, motivations and question links.
- An isolated map-selection-handler check updates the inspector to the intended point and question. This is a document-shell test, not a real browser interaction check.
- Application execution produces all tested route types, including sample, teacher, generated and quiz question deep links.
- The independent Apple-inspired stylesheet is local and last in the cascade.

The complete 1,720 × 7,690 detailed map and the separate topic-relationship SVG were rendered to PNG and inspected. Point-label text widths were measured to confirm that they do not overlap the question-reference column. SVG XML parsing and ZIP integrity checks passed.

**Verification limit:** the redesigned browser UI has not been visually or interactively rechecked in a browser. Browser local-file preview was restricted in this session. The checks above verify content, arithmetic, rendering functions, links, data layouts and exported diagrams; they do not replace real-browser focus, mobile layout, pan/zoom, download or end-to-end click testing.

## Arithmetic and retained v2 checks

**15 arithmetic and source-content groups passed again** after the redesign. Run `node tests/validate.cjs` to reproduce them:

- Numerically stable softmax, normalisation, shift invariance and cross-entropy.
- Temperature-scaled loss gradients checked by finite differences.
- Convolution output dimensions, parameter counts and invalid inputs.
- VAE KL and fixed-noise reparameterisation.
- PCA eigenpairs, explained variance, degenerate and invalid covariance cases.
- The supplied attention matrix, causal weights and outputs.
- The teacher's gradient-descent sequences and distinct limiting losses.
- Known inverse mixing and singular-matrix handling.
- All parameter gradients in four backpropagation presets checked by finite differences (four groups).
- Source/content counts, source-page resolution, exam allocations and answer integrity (three groups).

**9 new v2 groups passed.** Run `node tests/validate-v2.cjs` to reproduce them:

1. All 72 forecast questions have unique IDs and AI-generated provenance; every topic has four short and two long questions. Suggested scoring totals agree with the worked steps.
2. Independently recomputed numerical answers include the new least-squares, softmax, convolution pipeline, VAE, gradient-descent and attention examples.
3. Every one of the 12 topics appears exactly once in the mind-map grouping, with four exam-solving stages and six exam-strategy nodes.
4. Map branch bounds and non-overlap in overview, fully expanded and collapsed layouts.
5. The SVG and revision-outline exports contain all 40 concept headings and explicitly retain the source-coverage limitation.
6. The exported question bank labels all 72 questions AI-GENERATED and includes their suggested marks and worked answers.
7. Isolated application execution generates HTML for all 11 routes without an exception or undefined content. This uses a minimal document shell, not a browser or layout engine.
8. The original progress format and added generated-question review/bookmark/marking-point keys remain compatible.
9. Generated-question pagination renders 12 cards on the first page of six, and the map exposes detailed/overview controls.

The generated route documents and the SVG also parse successfully using an HTML/XML parser. The final ZIP's integrity and the presence of all ten original PDFs were verified.

## Previous diagram verification and browser limitation

The earlier v2 diagram was also rendered and inspected. The v3 diagram verification above supersedes it for the current export.

The preview tool rejected the local `file:` URL under its browser URL policy. Earlier real-browser checks applied to v1 and are not presented as verification of the v3 redesign.

The site remains a buildless set of local files, with no network dependencies. Open `index.html`, or run `node serve.js` and visit the printed loopback address. Embedded PDF behaviour depends on the browser; direct original-file links are included.

## Academic scope

The 72 new questions and suggested solutions are newly authored AI-generated practice forecasts. The original 48 quiz checks are also generated. “Sample-aligned” describes topic overlap with the recovered sample, not a future-exam probability. Free-text answers, marking-point checkboxes and review/confidence indicators are self-assessed. The sample specifies no official duration; the existing 90-minute default remains a configurable practice setting.
