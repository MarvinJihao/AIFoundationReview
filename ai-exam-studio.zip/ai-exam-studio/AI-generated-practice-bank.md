# AI-GENERATED — SEMTM0051 practice forecasts

Not official exam questions. Generated from the themes of 10 recovered PDFs; six attachments remain unavailable. Scores are suggested self-marking guides.

## G01 — A constant and its loss

**AI-GENERATED** | Regression & probability | Short answer | Sample-aligned | 2 marks

Targets are (3,5,10). Find the constant least-squares prediction and the minimum summed squared loss.

### Worked solution and suggested marks

1. Differentiate Σ(c−yᵢ)²: the minimiser is the mean c=(3+5+10)/3=6. [1 marks]
2. Minimum loss=(6−3)²+(6−5)²+(6−10)²=9+1+16=26. [1 marks]

## G02 — Nonlinear inputs, linear coefficients

**AI-GENERATED** | Regression & probability | Short answer | Sample-aligned | 2 marks

For f(x)=a+b x²+c exp(x), specify a feature row and explain whether ordinary linear-regression fitting applies.

### Worked solution and suggested marks

1. Choose ϕ(x)=(1,x²,exp(x)); put one such row per observation in X. [1 marks]
2. The prediction is linear in (a,b,c), so least-squares linear-regression methods apply; the inverse formula needs full column rank. [1 marks]

## G03 — A different softmax vector

**AI-GENERATED** | Regression & probability | Short answer | Sample-aligned | 2 marks

Logits are (ln 2,0,0). Find the probabilities and cross-entropy when the correct class is 3.

### Worked solution and suggested marks

1. Exponentials are (2,1,1), so p=(1/2,1/4,1/4). [1 marks]
2. CE=−ln(1/4)=ln4≈1.38629. [1 marks]

## G04 — A logit is not a probability

**AI-GENERATED** | Regression & probability | Short answer | Sample-aligned | 2 marks

A binary classifier has logit 0 and target 1. Find its probability, loss and loss derivative with respect to the logit.

### Worked solution and suggested marks

1. p=σ(0)=1/2; CE=−ln(1/2)=ln2≈0.69315. [1 marks]
2. The logit derivative is p−y=−1/2; it already includes the sigmoid derivative. [1 marks]

## G05 — Fit a straight line from first principles

**AI-GENERATED** | Regression & probability | Long answer | Sample-aligned | 10 marks

Fit y=a+bx by least squares to (0,1),(1,3),(2,5). Build the design matrix, solve the normal equations and check the residuals.

### Worked solution and suggested marks

1. Use X=[[1,0],[1,1],[1,2]] and y=(1,3,5)ᵀ. [2 marks]
2. XᵀX=[[3,3],[3,5]], Xᵀy=(9,13)ᵀ. [2 marks]
3. det(XᵀX)=6, so the inverse is (1/6)[[5,−3],[−3,3]]. [2 marks]
4. Multiplication gives a=1,b=2. [2 marks]
5. Predictions are (1,3,5), residuals all zero, summed squared loss zero. [2 marks]

## G06 — Softmax invariance and its training signal

**AI-GENERATED** | Regression & probability | Long answer | Sample-aligned | 10 marks

For a three-class classifier, explain shift invariance, derive the cross-entropy gradient with respect to logits, and apply it to equal logits with true class 1.

### Worked solution and suggested marks

1. Multiplying all exponentials by exp(c) shows softmax(a+c1)=softmax(a). [2 marks]
2. Write loss as −aᵧ+ln Σⱼ exp(aⱼ). [2 marks]
3. Differentiate coordinate k: ∂L/∂aₖ=pₖ−1[k=y]. [2 marks]
4. For equal logits, p=(1/3,1/3,1/3), loss ln3. [2 marks]
5. For true class 1 the gradient is (−2/3,1/3,1/3); its entries sum to zero. [2 marks]

## G07 — The final incomplete minibatch

**AI-GENERATED** | Training & optimisation | Short answer | Sample-aligned | 2 marks

A dataset has 1,025 examples and batch size 64. Count updates per epoch when retaining the final batch and when dropping it.

### Worked solution and suggested marks

1. Retaining the incomplete batch gives ceil(1025/64)=17 updates; the final batch has 1 example. [1 marks]
2. Dropping it gives floor(1025/64)=16 updates and omits 1 example that epoch. [1 marks]

## G08 — One descent update

**AI-GENERATED** | Training & optimisation | Short answer | Sample-aligned | 2 marks

For L(θ)=(θ−1)², start at θ=4 and use η=0.25. Compute one update and its loss.

### Worked solution and suggested marks

1. The gradient is 2(4−1)=6; θnew=4−0.25·6=2.5. [1 marks]
2. New loss=(2.5−1)²=2.25, down from 9. [1 marks]

## G09 — Read the loss curves

**AI-GENERATED** | Training & optimisation | Short answer | Sample-aligned | 2 marks

Model A ends with high, similar training and validation losses. Model B has low training loss but much higher validation loss. Diagnose both.

### Worked solution and suggested marks

1. A is consistent with underfitting or insufficient optimisation: it has not captured the training structure. [1 marks]
2. B is consistent with overfitting; inspect regularisation, data coverage and validation-based early stopping. [1 marks]

## G10 — Momentum with changing gradients

**AI-GENERATED** | Training & optimisation | Short answer | Sample-aligned | 2 marks

Use v←0.9v+g, w←w−0.1v. Start v=0,w=10. The first gradients are 2 then −1. Give both updated weights.

### Worked solution and suggested marks

1. First: v=2 and w=10−0.1·2=9.8. [1 marks]
2. Second: v=0.9·2−1=0.8 and w=9.8−0.08=9.72. [1 marks]

## G11 — Revisit the two-basin example

**AI-GENERATED** | Training & optimisation | Long answer | Sample-aligned | 10 marks

Use the teacher loss L=2(θ+3)² for θ≤−1, 2(θ+1)²+8 for −1<θ<1, and 2(θ−3)²+8 for θ≥1. With η=0.1, take two steps from −2 and from 2. Interpret the result.

### Worked solution and suggested marks

1. In the outer regions the gradients are 4(θ+3) and 4(θ−3). [2 marks]
2. Left run: −2→−2.4→−2.64, with losses 2→0.72→0.2592. [2 marks]
3. Right run: 2→2.4→2.64, with losses 10→8.72→8.2592. [2 marks]
4. The distances to −3 or 3 shrink by factor 0.6 per step while the run remains in its basin. [2 marks]
5. Limits have losses 0 and 8; decreasing loss and zero gradient do not guarantee a global optimum. [2 marks]

## G12 — Compare optimisation strategies without overclaiming

**AI-GENERATED** | Training & optimisation | Long answer | Sample-aligned | 10 marks

Explain full-batch GD, minibatch SGD, momentum and Adam. A student says SGD and a wider network always escape every bad minimum. Assess the claim.

### Worked solution and suggested marks

1. Full-batch GD uses the gradient over all examples; minibatch SGD estimates it from a sampled batch. [2 marks]
2. Momentum accumulates directions, for example v←βv+g; w←w−ηv. [2 marks]
3. Adam tracks first and second gradient moments and rescales updates coordinatewise; specify whether bias correction is included. [2 marks]
4. Minibatch noise may help leave some regions, but can also vanish at a nonglobal point when all example gradients vanish. [2 marks]
5. Wider networks and restarts can help empirically but supply no general guarantee; compare validation behaviour as well as training fit. [2 marks]

## G13 — Count a new architecture

**AI-GENERATED** | Neural networks | Short answer | Sample-aligned | 2 marks

A fully connected 4→6→3 network has biases in both layers. State weight shapes and total parameter count.

### Worked solution and suggested marks

1. W₁ has shape 4×6; W₂ has shape 6×3. Biases have widths 6 and 3. [1 marks]
2. Count=(24+6)+(18+3)=51 trainable parameters. [1 marks]

## G14 — Collapse affine maps with biases

**AI-GENERATED** | Neural networks | Short answer | Sample-aligned | 2 marks

For u(x)=xA+b and v(z)=zC+d, write the equivalent single affine map. What changes if a nonlinearity is inserted?

### Worked solution and suggested marks

1. v(u(x))=x(AC)+(bC+d), which is still affine. [1 marks]
2. Inserting a nonlinearity can create changes of slope or more complex boundaries; it cannot generally be collapsed to one affine map. [1 marks]

## G15 — A new ReLU breakpoint

**AI-GENERATED** | Neural networks | Short answer | Sample-aligned | 2 marks

Write ReLU(3x+6) piecewise and identify its breakpoint and slopes.

### Worked solution and suggested marks

1. The breakpoint is x=−2. The output is 0 for x≤−2 and 3x+6 for x>−2. [1 marks]
2. The slopes are 0 and 3; the ordinary derivative at the breakpoint does not exist. [1 marks]

## G16 — Identical representations

**AI-GENERATED** | Neural networks | Short answer | Sample-aligned | 2 marks

Two different inputs produce the same hidden row h under a fixed encoder. Can any shared final affine layer separate them?

### Worked solution and suggested marks

1. No: hW+b is identical for both inputs, for every choice of W and b. [1 marks]
2. The feature map must change or gain distinguishing information; changing only the shared final layer cannot recover lost distinctions. [1 marks]

## G17 — A complete new forward pass

**AI-GENERATED** | Neural networks | Long answer | Sample-aligned | 10 marks

Use x=(1,−1), W₁=[[1,2],[−1,1]], b₁=(0,1), W₂=(2,−1)ᵀ and b₂=0. Compute the forward values and interpret the output for regression y=1 and binary classification y=1.

### Worked solution and suggested marks

1. a₁=(1,−1)W₁+(0,1)=(2,2). [2 marks]
2. ReLU gives h=(2,2); f=2·2+2·(−1)=2. [2 marks]
3. Regression loss=(2−1)²=1. [2 marks]
4. Binary probability σ(2)≈0.880797, hence predicted class 1. [2 marks]
5. Binary CE=−ln σ(2)=ln(1+e⁻²)≈0.126928; the same raw output has different task-specific interpretation. [2 marks]

## G18 — Design and analyse a ReLU tent

**AI-GENERATED** | Neural networks | Long answer | Sample-aligned | 10 marks

Construct T(x)=ReLU(x)−2ReLU(x−1)+ReLU(x−2). Give its piecewise form and network parameters, and explain what this says about nonlinear feature composition.

### Worked solution and suggested marks

1. For x≤0, T=0; for 0<x≤1, T=x. [2 marks]
2. For 1<x<2, T=2−x; for x≥2, T=0. It is continuous and T(1)=1. [2 marks]
3. Take W₁=(1,1,1), b₁=(0,−1,−2). [2 marks]
4. Take W₂=(1,−2,1)ᵀ and b₂=0. [2 marks]
5. The slopes change at 0,1,2, proving the output is not one affine map. Different ReLU features create these changes. [2 marks]

## G19 — Read an outer-product entry

**AI-GENERATED** | Backpropagation | Short answer | Sample-aligned | 2 marks

For x=(3,−1) and hidden backward row δ=(2,−4), compute the weight and bias gradients for the first layer.

### Worked solution and suggested marks

1. ∇W=xᵀδ=[[6,−12],[−2,4]]. [1 marks]
2. ∇b=δ=(2,−4); shapes match a 2×2 weight matrix and a 1×2 bias. [1 marks]

## G20 — Gate a negative gradient correctly

**AI-GENERATED** | Backpropagation | Short answer | Sample-aligned | 2 marks

Saved preactivations are (2,−1,4); the backward row before the ReLU gate is (−3,5,−2). What row passes through the gate?

### Worked solution and suggested marks

1. The saved gate is (1,0,1), so the result is (−3,0,−2). [1 marks]
2. The gate depends on preactivation signs, not gradient signs: negative gradients remain at positive preactivations. [1 marks]

## G21 — Sum versus mean

**AI-GENERATED** | Backpropagation | Short answer | Sample-aligned | 2 marks

Four example gradients for one parameter are (2,−1,3,0). Give the gradient of the summed loss and mean loss.

### Worked solution and suggested marks

1. Summed loss gradient=2−1+3+0=4. [1 marks]
2. Mean loss gradient=4/4=1. Keep reduction and learning-rate conventions consistent. [1 marks]

## G22 — Output gradient for another target

**AI-GENERATED** | Backpropagation | Short answer | Sample-aligned | 2 marks

A three-class prediction is p=(0.2,0.5,0.3) and the correct class is 3. Give the softmax CE logit gradient.

### Worked solution and suggested marks

1. Subtract the target one-hot vector (0,0,1). [1 marks]
2. δ=(0.2,0.5,−0.7). No additional softmax derivative factor is needed. [1 marks]

## G23 — Full gradient calculation with two active hidden units

**AI-GENERATED** | Backpropagation | Long answer | Sample-aligned | 10 marks

Use x=(1,−1), y=1, W₁=[[1,2],[−1,1]], b₁=(0,1), W₂=(2,−1)ᵀ, b₂=0 and squared loss. Compute all gradients at the saved forward parameters.

### Worked solution and suggested marks

1. Forward: a₁=h=(2,2), f=2 and L=1. [2 marks]
2. δ₂=2(f−y)=2, giving ∇W₂=(4,4)ᵀ and ∇b₂=2. [2 marks]
3. Before the gate: 2(2,−1)=(4,−2); both saved preactivations are positive, so δ₁=(4,−2). [2 marks]
4. ∇W₁=xᵀδ₁=[[4,−2],[−4,2]], ∇b₁=(4,−2). [2 marks]
5. Only now update each parameter by subtracting η times its gradient; using updated W₂ earlier would mix parameter settings. [2 marks]

## G24 — Derive and apply the remaining-loss recursion

**AI-GENERATED** | Backpropagation | Long answer | Sample-aligned | 10 marks

For row activations, define Jᵣ and derive parameter gradients and the preceding backward row for a ReLU hidden layer. State regression, binary and multiclass initialisations.

### Worked solution and suggested marks

1. Jᵣ(u) is the remaining loss from a hypothetical preactivation u, holding target and later parameters fixed; δᵣ=∇Jᵣ(aᵣ). [2 marks]
2. An affine weight (Wᵣ)ₖⱼ contributes input ϕᵣ₋₁,ₖ to aᵣ,ⱼ, hence ∇Wᵣ=ϕᵣ₋₁ᵀδᵣ and ∇bᵣ=δᵣ. [2 marks]
3. Chain rule sums downstream contributions into δᵣWᵣᵀ; apply the preceding saved ReLU gate elementwise. [2 marks]
4. Initialisations: squared loss 2(f−y); sigmoid CE p−y; softmax CE p−one-hot(y). [2 marks]
5. Cache forward values, reuse backward rows and complete all gradients before updating. At ReLU zero use a stated computational convention. [2 marks]

## G25 — An eigensystem with another variance ratio

**AI-GENERATED** | Principal component analysis | Short answer | Coverage extension | 2 marks

A covariance matrix is [[5,0],[0,1]]. Give both principal directions and the first explained-variance ratio.

### Worked solution and suggested marks

1. Eigenvalues are 5 and 1, with unit directions (1,0) and (0,1), up to sign. [1 marks]
2. First explained-variance ratio=5/6≈83.33%. [1 marks]

## G26 — Restore the mean after projection

**AI-GENERATED** | Principal component analysis | Short answer | Coverage extension | 2 marks

Mean μ=(2,3)ᵀ, loading e₁=(1,0)ᵀ, and observation x=(5,7)ᵀ. Find its retained score and reconstruction.

### Worked solution and suggested marks

1. Centred point is (3,4)ᵀ, so y₁=e₁ᵀ(x−μ)=3. [1 marks]
2. Reconstruct μ+e₁y₁=(5,3)ᵀ. Discarded residual is (0,4)ᵀ with squared norm 16. [1 marks]

## G27 — Correlation is not full whitening

**AI-GENERATED** | Principal component analysis | Short answer | Coverage extension | 2 marks

Distinguish standardising each feature from PCA whitening.

### Worked solution and suggested marks

1. Standardisation divides each centred feature by its own standard deviation, producing the correlation matrix; off-diagonal covariance can remain. [1 marks]
2. PCA whitening rotates into eigenvectors and rescales retained nonzero-variance components by 1/√λ, giving identity covariance there. [1 marks]

## G28 — Signs and repeated eigenvalues

**AI-GENERATED** | Principal component analysis | Short answer | Coverage extension | 2 marks

Why can two PCA implementations return opposite loading signs or different axes for equal eigenvalues?

### Worked solution and suggested marks

1. Multiplying a loading and its scores by −1 preserves its subspace and reconstruction. [1 marks]
2. An eigenspace with repeated eigenvalues admits multiple orthonormal bases; its subspace is meaningful even when individual directions are not unique. [1 marks]

## G29 — A complete two-dimensional PCA calculation

**AI-GENERATED** | Principal component analysis | Long answer | Coverage extension | 10 marks

For centred column data with covariance Σ=[[3,1],[1,3]], find eigenpairs, project x=(2,0)ᵀ onto one principal component, reconstruct it and quantify retained variance and pointwise error.

### Worked solution and suggested marks

1. det(Σ−λI)=(3−λ)²−1, giving λ₁=4 and λ₂=2. [2 marks]
2. Choose e₁=(1,1)/√2, e₂=(1,−1)/√2. [2 marks]
3. Retained score e₁ᵀx=√2 and reconstruction e₁√2=(1,1)ᵀ. [2 marks]
4. Retained population/sample covariance variance fraction=4/(4+2)=2/3. [2 marks]
5. This point has residual (1,−1)ᵀ, squared error 2. Distinguish its pointwise error from the aggregate variance fraction. [2 marks]

## G30 — Interpret a constrained data matrix

**AI-GENERATED** | Principal component analysis | Long answer | Coverage extension | 10 marks

Explain PCA for 43 observations with 11 vote-share features summing to one. Include centring, scaling, loadings/scores, rank and interpretation caveats.

### Worked solution and suggested marks

1. Use one row per observation and centre each feature. The centred rows sum to zero across the 11 share coordinates. [2 marks]
2. The constant-sum relation limits feature rank to at most 10, even with 43 observations. [2 marks]
3. Covariance PCA uses meaningful absolute scales; correlation PCA balances standardised variances. Scaling alone does not remove linear dependence. [2 marks]
4. Loadings are eigenvector columns; row-wise scores are Xcentred P. Keep leading eigenvalues for dimension reduction. [2 marks]
5. Axis labels require external interpretation, can flip sign and need not be causal or independent; variance importance is not supervised predictive importance. [2 marks]

## G31 — Invert a known mixture

**AI-GENERATED** | Independent component analysis | Short answer | Coverage extension | 2 marks

Let y₁=s₁+s₂, y₂=s₁−s₂. Recover s₁ and s₂ in terms of y.

### Worked solution and suggested marks

1. Adding the equations gives s₁=(y₁+y₂)/2. [1 marks]
2. Subtracting gives s₂=(y₁−y₂)/2. This uses a known mixing matrix; estimating it is the ICA task. [1 marks]

## G32 — Why covariance is insufficient

**AI-GENERATED** | Independent component analysis | Short answer | Coverage extension | 2 marks

Why does decorrelating mixed sources with PCA not generally complete ICA?

### Worked solution and suggested marks

1. Zero covariance constrains second-order dependence but permits other statistical dependence. [1 marks]
2. ICA uses independence/non-Gaussian structure beyond covariance; PCA generally supplies uncorrelated, not independent, scores. [1 marks]

## G33 — Which sources are identifiable?

**AI-GENERATED** | Independent component analysis | Short answer | Coverage extension | 2 marks

Why are several independent Gaussian sources problematic for linear ICA?

### Worked solution and suggested marks

1. After whitening, orthogonal rotations of a spherical Gaussian remain Gaussian with independent coordinates. [1 marks]
2. Independence cannot select a unique source orientation in that Gaussian subspace; standard identifiable linear ICA permits at most one Gaussian source under its usual assumptions. [1 marks]

## G34 — Interpret an embedding component

**AI-GENERATED** | Independent component analysis | Short answer | Coverage extension | 2 marks

You rank words on an ICA coordinate and see guitar, vocals, albums, jazz. Give a plausible interpretation and a check.

### Worked solution and suggested marks

1. The coordinate plausibly captures music-related usage. [1 marks]
2. Check held-out high/low-activation words or interventions; coherent examples support a hypothesis but do not establish a guaranteed causal concept. [1 marks]

## G35 — From observed mixtures to independent coordinates

**AI-GENERATED** | Independent component analysis | Long answer | Coverage extension | 10 marks

Outline the linear ICA model, preprocessing, FastICA intuition, ambiguities and diagnostics for recovering two speakers.

### Worked solution and suggested marks

1. Assume observations y=Ms from independent source coordinates with adequate non-Gaussian structure and invertible mixing. [2 marks]
2. Centre and often whiten observations to simplify the search; whitening itself does not identify independent sources. [2 marks]
3. FastICA seeks non-Gaussian projections, motivated by mixtures tending to look more Gaussian. [2 marks]
4. Recoveries are ambiguous up to scale/sign and permutation; the true mixing matrix is unknown in an actual task. [2 marks]
5. Inspect recovered signals and dependence diagnostics, and check model assumptions such as noise, mixing adequacy and source distributions. [2 marks]

## G36 — Compare three ways to represent the same data

**AI-GENERATED** | Independent component analysis | Long answer | Coverage extension | 10 marks

Compare PCA, ICA and a sparse autoencoder as representation-learning tools. Address objectives, transformations, interpretability, and what is not guaranteed.

### Worked solution and suggested marks

1. PCA finds orthogonal directions maximising retained variance and minimising linear squared reconstruction error. [2 marks]
2. ICA seeks independent source coordinates using higher-order/non-Gaussian information; the mixing model is linear but need not have orthogonal source directions. [2 marks]
3. A sparse AE optimises reconstruction plus an activation sparsity penalty and can use a nonlinear encoder and a wide dictionary. [2 marks]
4. Interpretability is checked using loadings, top-activating examples or interventions, depending on the method. [2 marks]
5. Neither high variance, independence objectives nor sparse activation alone guarantees that every coordinate is a useful human concept or a causal feature. [2 marks]

## G37 — Another Gaussian KL

**AI-GENERATED** | Autoencoders & latent models | Short answer | Sample-aligned | 2 marks

Compute KL(N(2,1) ‖ N(0,1)).

### Worked solution and suggested marks

1. Here μ=2 and σ=1; use ½(μ²+σ²−1−lnσ²). [1 marks]
2. KL=½(4+1−1−0)=2. [1 marks]

## G38 — A fixed-noise latent sample

**AI-GENERATED** | Autoencoders & latent models | Short answer | Sample-aligned | 2 marks

Let μ=−1, σ=0.5 and ε=2. Compute z, ∂z/∂μ and ∂z/∂σ.

### Worked solution and suggested marks

1. z=μ+σε=−1+0.5·2=0. [1 marks]
2. With ε held fixed, derivatives are 1 and ε=2. [1 marks]

## G39 — Which distribution for which job?

**AI-GENERATED** | Autoencoders & latent models | Short answer | Sample-aligned | 2 marks

Distinguish latent sampling for reconstructing a given x and generating a new x in a VAE.

### Worked solution and suggested marks

1. For reconstruction, sample from encoder qϕ(z|x) conditioned on the observed input, then decode. [1 marks]
2. For fresh generation, sample from prior p(z), then decode; no given input is needed. [1 marks]

## G40 — A wider but sparse hidden layer

**AI-GENERATED** | Autoencoders & latent models | Short answer | Sample-aligned | 2 marks

Why can a sparse AE have more hidden units than input coordinates without simply being an identity-copy model?

### Worked solution and suggested marks

1. The wide hidden layer offers a large dictionary of candidate feature directions. [1 marks]
2. An L1 activation penalty encourages few active units per input; reconstruction and sparsity jointly constrain the representation. [1 marks]

## G41 — ELBO signs, numbers and sampling

**AI-GENERATED** | Autoencoders & latent models | Long answer | Sample-aligned | 10 marks

A VAE has one-dimensional q=N(1,0.25) and standard normal prior. Explain the ELBO, calculate KL, give a reparameterised sample at ε=−2, and describe generation.

### Worked solution and suggested marks

1. ELBO=E_q[ln pθ(x|z)]−KL(q‖p), maximised; negative ELBO is a loss to minimise. [2 marks]
2. q has μ=1, variance 0.25, standard deviation σ=0.5. [2 marks]
3. KL=½(1+0.25−1−ln0.25)≈0.818147. [2 marks]
4. At ε=−2, z=1+0.5(−2)=0; for fixed ε, ∂z/∂μ=1 and ∂z/∂σ=−2. [2 marks]
5. To generate, sample z from N(0,1) and decode. KL aligns latent distributions with the prior; dropping it can make prior samples decode poorly. [2 marks]

## G42 — Check a sparse language-model feature

**AI-GENERATED** | Autoencoders & latent models | Long answer | Sample-aligned | 10 marks

Design a test for whether an SAE feature represents code-related text, using the loss ‖x−Wd h‖²+λ‖h‖₁. Explain what changes as λ increases.

### Worked solution and suggested marks

1. A feature is one hidden coordinate / decoder column, a direction in the language-model activation space. [2 marks]
2. Gather top-activating and low-activating text and hypothesise a coherent code-related property. [2 marks]
3. Evaluate the hypothesis on held-out text and controls, not just cherry-picked high activations. [2 marks]
4. Intervene by adding/removing the feature direction and inspect predicted changes in behaviour, while checking confounds. [2 marks]
5. Larger λ generally favours fewer/smaller activations at a reconstruction trade-off; sparsity does not guarantee every feature is interpretable. [2 marks]

## G43 — Spatial dimensions without padding

**AI-GENERATED** | Convolution & image geometry | Short answer | Sample-aligned | 2 marks

A 32×32 input uses K=5, P=0, S=1, then 2×2 pooling with stride 2. Give both spatial sizes.

### Worked solution and suggested marks

1. Convolution: floor((32−5)/1)+1=28, so 28×28. [1 marks]
2. Pooling: floor((28−2)/2)+1=14, so 14×14. [1 marks]

## G44 — Count another convolution

**AI-GENERATED** | Convolution & image geometry | Short answer | Sample-aligned | 2 marks

A 3×3 layer maps 3 input channels to 16 output channels. Count weights and biases.

### Worked solution and suggested marks

1. Weights=3·3·3·16=432. [1 marks]
2. Add 16 biases, total 448. [1 marks]

## G45 — Depthwise separation savings

**AI-GENERATED** | Convolution & image geometry | Short answer | Sample-aligned | 2 marks

Compare weight counts for standard and depthwise-plus-pointwise 3×3 convolution with Cin=8,Cout=16. Omit biases consistently.

### Worked solution and suggested marks

1. Standard: 9·8·16=1152 weights. [1 marks]
2. Separated: 9·8+8·16=200 weights, about 17.36% of standard. [1 marks]

## G46 — What a 1×1 layer does

**AI-GENERATED** | Convolution & image geometry | Short answer | Sample-aligned | 2 marks

Does a 1×1 convolution combine neighbouring pixels? What useful transformation does it perform?

### Worked solution and suggested marks

1. At stride 1 it operates independently at each spatial position and does not directly mix neighbouring positions. [1 marks]
2. It mixes input channels and can reduce or expand channel width, for example before an expensive 3×3 convolution. [1 marks]

## G47 — Trace two convolutions and pooling

**AI-GENERATED** | Convolution & image geometry | Long answer | Sample-aligned | 10 marks

Start with 64×64×3. Apply conv A: K=3,P=1,S=1,Cout=8; 2×2 stride-2 pooling; conv B: K=3,P=0,S=2,Cout=16. Give shapes and parameter totals including biases.

### Worked solution and suggested marks

1. A spatial size is 64, output shape 64×64×8. [2 marks]
2. A parameters=8(3·9+1)=224. [2 marks]
3. Pooling gives 32×32×8 with no trainable weights. [2 marks]
4. B spatial size=floor((32−3)/2)+1=15, output 15×15×16. [2 marks]
5. B parameters=16(8·9+1)=1168; total trainable parameters=224+1168=1392. [2 marks]

## G48 — Explain parameter efficiency precisely

**AI-GENERATED** | Convolution & image geometry | Long answer | Sample-aligned | 10 marks

Explain why convolution is parameter-efficient, how channel counts enter, how depthwise separation changes computation, and why fewer weights do not guarantee a proportional speedup.

### Worked solution and suggested marks

1. A local kernel connects an output to a limited input patch rather than every image coordinate. [2 marks]
2. The same kernel is reused across spatial positions, so learned parameter count is independent of image width/height. [2 marks]
3. A standard K×K layer has K²CinCout weights plus one bias per output channel. [2 marks]
4. Depthwise spatial filters plus 1×1 mixing use K²Cin+CinCout weights, omitting biases for comparison. [2 marks]
5. Actual speed depends on activation sizes, memory access, hardware and implementation; parameter count alone is not a latency measurement. [2 marks]

## G49 — Residual addition or concatenation?

**AI-GENERATED** | Vision architectures & detection | Short answer | Coverage extension | 2 marks

Compare the defining feature connection in ResNet and DenseNet.

### Worked solution and suggested marks

1. ResNet adds a residual transformation to a compatible input: y=x+F(x). [1 marks]
2. DenseNet concatenates earlier feature maps, preserving them as additional channels for reuse. [1 marks]

## G50 — Who proposes regions?

**AI-GENERATED** | Vision architectures & detection | Short answer | Coverage extension | 2 marks

Distinguish Fast R-CNN from Faster R-CNN at the proposal stage.

### Worked solution and suggested marks

1. Fast R-CNN shares image convolutional features and pools externally proposed regions. [1 marks]
2. Faster R-CNN introduces a learned region proposal network on shared features. [1 marks]

## G51 — From pixels to ViT tokens

**AI-GENERATED** | Vision architectures & detection | Short answer | Coverage extension | 2 marks

Describe the conversion of an image to a standard ViT input sequence.

### Worked solution and suggested marks

1. Split the image into patches and linearly embed each flattened patch. [1 marks]
2. Add position information and, in the standard classification design in the slides, a class token before the Transformer encoder. [1 marks]

## G52 — What does shifting a window achieve?

**AI-GENERATED** | Vision architectures & detection | Short answer | Coverage extension | 2 marks

Why shift local attention windows between Swin layers?

### Worked solution and suggested marks

1. Local attention limits interactions within a window in one layer. [1 marks]
2. Shifting partitions connects tokens across earlier window boundaries, exchanging information while retaining local attention structure. [1 marks]

## G53 — Design a detector and segmenter comparison

**AI-GENERATED** | Vision architectures & detection | Long answer | Coverage extension | 10 marks

Compare classification, object detection, semantic segmentation and instance segmentation. Explain how R-CNN, Faster R-CNN, YOLO and Mask R-CNN fit these tasks.

### Worked solution and suggested marks

1. Classification predicts image labels; detection adds object bounding boxes and classes. [2 marks]
2. Semantic segmentation assigns a category to each pixel; instance segmentation separates individual objects. [2 marks]
3. R-CNN uses proposed regions and CNN features; repeated per-region extraction can be expensive. [2 marks]
4. Faster R-CNN learns proposals using an RPN; YOLO uses a single-stage detection pipeline. [2 marks]
5. Mask R-CNN adds instance masks to a region-based detector; a dense semantic model such as U-Net is a different output formulation. [2 marks]

## G54 — Compare five routes to scalable visual representations

**AI-GENERATED** | Vision architectures & detection | Long answer | Coverage extension | 10 marks

Compare VGG, Inception, ResNet, EfficientNet and ViT. Explain a benefit of each and why architecture choice is a trade-off.

### Worked solution and suggested marks

1. VGG stacks small kernels to form a simple deep hierarchy with repeated blocks. [2 marks]
2. Inception processes multiple scales in parallel and uses channel reductions for efficiency. [2 marks]
3. ResNet uses additive residual paths to help optimisation of deep networks. [2 marks]
4. EfficientNet balances depth, width and input resolution through compound scaling. [2 marks]
5. ViT uses patch tokens and self-attention; data, computation, locality bias and downstream tasks influence which design is suitable. [2 marks]

## G55 — Autoregression as a product

**AI-GENERATED** | Generative vision models | Short answer | Coverage extension | 2 marks

Write an autoregressive factorisation of a sequence of four pixels or tokens and state the sampling order.

### Worked solution and suggested marks

1. p(x₁:₄)=p(x₁)p(x₂|x₁)p(x₃|x₁:₂)p(x₄|x₁:₃). [1 marks]
2. Generate in that order, conditioning each step only on already generated variables; training masks must prevent future leakage. [1 marks]

## G56 — Why a flow must be invertible

**AI-GENERATED** | Generative vision models | Short answer | Coverage extension | 2 marks

Why do normalising flows impose invertible transformations, unlike a general bottleneck AE?

### Worked solution and suggested marks

1. Invertibility permits mapping between data and base variables while using a Jacobian determinant to transform densities. [1 marks]
2. A lossy dimension-reducing bottleneck generally cannot recover a unique inverse or use that same exact change-of-variables density formula. [1 marks]

## G57 — GAN roles

**AI-GENERATED** | Generative vision models | Short answer | Coverage extension | 2 marks

Describe the roles of a GAN generator and discriminator without calling the discriminator the generator’s decoder.

### Worked solution and suggested marks

1. The generator transforms a random latent input into a candidate sample. [1 marks]
2. The discriminator learns to distinguish real from generated samples; its adversarial signal trains the generator. [1 marks]

## G58 — Why diffuse in latent space?

**AI-GENERATED** | Generative vision models | Short answer | Coverage extension | 2 marks

What is the main representation and efficiency idea in latent diffusion?

### Worked solution and suggested marks

1. Encode data into a compressed learned latent representation and learn a denoising process there. [1 marks]
2. After reverse denoising, decode the latent to an image; the expensive denoising operates on a smaller representation. [1 marks]

## G59 — Four generative mechanisms, four sampling stories

**AI-GENERATED** | Generative vision models | Long answer | Coverage extension | 10 marks

Compare VAE, GAN, normalising flow and diffusion. Give the defining training signal and the sampling mechanism of each.

### Worked solution and suggested marks

1. A VAE maximises reconstruction log-likelihood minus KL; sample the prior and decode. [2 marks]
2. A GAN trains adversarially against a discriminator/critic; map latent noise through the generator. [2 marks]
3. A normalising flow transforms a base density invertibly with Jacobian corrections; sample the base and transform forward. [2 marks]
4. Diffusion learns a reverse denoising process corresponding to a forward noising process; start from noise and iteratively denoise. [2 marks]
5. These mechanisms have different objectives and sampling costs; an encoder, explicit tractable likelihood or VAE ELBO is not shared by every family. [2 marks]

## G60 — Link denoising, masking and generation

**AI-GENERATED** | Generative vision models | Long answer | Coverage extension | 10 marks

Compare a denoising AE, masked image AE, PixelCNN, and diffusion. Explain where targets come from and which restrictions prevent trivial information leakage.

### Worked solution and suggested marks

1. Denoising AE: corrupt an input and reconstruct the original clean target, learning robust representations. [2 marks]
2. Masked image AE: hide image patches and reconstruct missing content using self-supervised targets. [2 marks]
3. PixelCNN: predict pixels conditional on earlier pixels under an autoregressive ordering. [2 marks]
4. Its masked convolutions block future-pixel information; a zero-valued score alone is not a mask. [2 marks]
5. Diffusion trains on controlled noise corruption to learn reverse denoising; a denoising representation learner is not automatically the same complete generative process. [2 marks]

## G61 — A tiny BPE training step

**AI-GENERATED** | Tokens & word representations | Short answer | Coverage extension | 2 marks

The corpus contains the words low twice and lower once. Start each word as characters, with merges not crossing word boundaries and no end-of-word symbol. Which adjacent pairs tie for the highest frequency?

### Worked solution and suggested marks

1. The within-word pairs (l,o) and (o,w) each occur three times; (w,e) and (e,r) each occur once. [1 marks]
2. A specified tie-break rule selects the next merge. Training frequencies are not recomputed from a test sentence at inference. [1 marks]

## G62 — A table lookup is a matrix product

**AI-GENERATED** | Tokens & word representations | Short answer | Coverage extension | 2 marks

For vocabulary size V and embedding width d, give the embedding matrix shape and explain one-hot multiplication.

### Worked solution and suggested marks

1. An embedding table has V rows and d columns. [1 marks]
2. A one-hot row for vocabulary item i times the table selects its ith embedding row. [1 marks]

## G63 — Skip-gram versus CBOW

**AI-GENERATED** | Tokens & word representations | Short answer | Coverage extension | 2 marks

State which variable is predicted from which for skip-gram and CBOW.

### Worked solution and suggested marks

1. Skip-gram predicts nearby context words from a centre word. [1 marks]
2. CBOW predicts a centre word from a bag of context words. [1 marks]

## G64 — What negative sampling saves

**AI-GENERATED** | Tokens & word representations | Short answer | Coverage extension | 2 marks

Why can negative sampling be cheaper than a full vocabulary softmax in Word2Vec?

### Worked solution and suggested marks

1. It updates a positive target and a small number of sampled negative words rather than normalising over all vocabulary words. [1 marks]
2. It uses a distinct training objective/approximation strategy; its selected-word updates should not be described as evaluating an identical full softmax. [1 marks]

## G65 — Train and apply a tiny BPE vocabulary

**AI-GENERATED** | Tokens & word representations | Long answer | Coverage extension | 10 marks

Use the words low (frequency 2) and lower (frequency 1), with characters and no cross-word merges or boundary markers. Break a first-step tie by selecting (l,o). Take two merge steps, then apply the learned rules to lower.

### Worked solution and suggested marks

1. Initially (l,o) and (o,w) both have count 3, the highest frequency. [2 marks]
2. By the stated tie break merge l+o→lo; the word sequences become [lo,w] and [lo,w,e,r]. [2 marks]
3. The pair (lo,w) now has count 3, so merge lo+w→low. [2 marks]
4. At inference start [l,o,w,e,r], apply the learned ordered merges to obtain [low,e,r]. [2 marks]
5. The rules were trained on the corpus; inference applies those rules and does not relearn them on the new word. Different tie breaks can produce different vocabularies. [2 marks]

## G66 — From one-hot identity to semantic geometry

**AI-GENERATED** | Tokens & word representations | Long answer | Coverage extension | 10 marks

Explain one-hot vectors, co-occurrence/SVD, skip-gram, and contextual embeddings. Discuss similarity and limits of semantic interpretations.

### Worked solution and suggested marks

1. Distinct one-hot vectors are orthogonal and encode identity rather than a learned similarity. [2 marks]
2. Co-occurrence counts use context; SVD can reduce dimensionality but faces very large sparse matrices and changing vocabularies. [2 marks]
3. Skip-gram learns dense vectors by predicting contexts, commonly with efficient objectives such as negative sampling. [2 marks]
4. A contextual Transformer changes the representation of a token depending on its sequence; static word vectors do not do this. [2 marks]
5. Cosine similarity and analogies probe geometry, but selected examples and coherent axes do not guarantee universal or causal semantic meaning. [2 marks]

## G67 — Another causal row

**AI-GENERATED** | Attention & Transformers | Short answer | Sample-aligned | 2 marks

Two value vectors are v₁=(2,0), v₂=(0,2). At position 2 the visible scores are (0,ln3). Find weights and output.

### Worked solution and suggested marks

1. Softmax weights are (1/(1+3),3/(1+3))=(1/4,3/4). [1 marks]
2. Output=(1/4)(2,0)+(3/4)(0,2)=(0.5,1.5). [1 marks]

## G68 — Count dense score entries

**AI-GENERATED** | Attention & Transformers | Short answer | Sample-aligned | 2 marks

Ignoring head count, a context increases from 128 tokens to 512. Compare dense self-attention score counts.

### Worked solution and suggested marks

1. Counts are 128²=16,384 and 512²=262,144. [1 marks]
2. The factor is (512/128)²=16; widths and head counts are held fixed. [1 marks]

## G69 — A zero is not negative infinity

**AI-GENERATED** | Attention & Transformers | Short answer | Sample-aligned | 2 marks

Why is replacing a masked score by 0 not generally a correct causal mask?

### Worked solution and suggested marks

1. exp(0)=1, so a score of 0 receives a positive softmax contribution. [1 marks]
2. A removed position must have zero weight, usually by adding −∞ before row-wise softmax. [1 marks]

## G70 — Architecture and objective

**AI-GENERATED** | Attention & Transformers | Short answer | Sample-aligned | 2 marks

Match GPT-style, BERT-style and T5-style models to attention context and objectives.

### Worked solution and suggested marks

1. GPT-style decoder-only models use causal context for next-token prediction; BERT-style encoders use bidirectional context for masked-token prediction. [1 marks]
2. T5-style encoder–decoders use an input encoder, causal output self-attention and cross-attention for text-to-text tasks. [1 marks]

## G71 — Compute a complete unscaled causal attention layer

**AI-GENERATED** | Attention & Transformers | Long answer | Sample-aligned | 10 marks

Use x₁=(1,0), x₂=(1,1), x₃=(0,1), Q=K=V=X, and no √d scaling. Compute raw scores, mask, weights, and all outputs.

### Worked solution and suggested marks

1. Raw scores are [[1,1,0],[1,2,1],[0,1,1]]. [2 marks]
2. Causal masking removes (1,2),(1,3),(2,3), replacing them by −∞. [2 marks]
3. Row 1 weights=(1,0,0), output (1,0). Row 2 visible weights=(1/(1+e),e/(1+e))≈(0.268941,0.731059), output (1,0.731059). [2 marks]
4. Row 3 weights=(1,e,e)/(1+2e)≈(0.155362,0.422319,0.422319). [2 marks]
5. Row 3 output=(w₁+w₂,w₂+w₃)≈(0.577681,0.844638). Each row of weights sums to one. [2 marks]

## G72 — Design a Transformer answer that earns explanation marks

**AI-GENERATED** | Attention & Transformers | Long answer | Sample-aligned | 10 marks

Explain queries, keys, values, self/cross-attention, causal masks, multiple heads, positional information and sequence-length cost.

### Worked solution and suggested marks

1. Queries encode what is sought, keys encode matching properties, and values contain the retrieved content. [2 marks]
2. Self-attention uses one sequence for Q,K,V; cross-attention uses queries from one sequence and keys/values from another. [2 marks]
3. A causal mask excludes j>i to prevent future leakage in next-token training; row-wise softmax turns allowed scores into weights. [2 marks]
4. Multiple learned projections provide heads with different subspaces/attention patterns; positional information supplies order absent from content-only attention. [2 marks]
5. Compute weighted values and combine heads; dense score storage scales as n² for fixed head count, so doubling context quadruples it. [2 marks]
